/* ============================================================
   Rasaia Clean AI — App shell & router
   ============================================================ */

function App() {
  const [view, setView] = useState("landing");
  const [companyTab, setCompanyTab] = useState("dashboard");
  const [selected, setSelected] = useState(null);

  const [quoteInput, setQuoteInput] = useState({ propertyType: "apartment", size: 1150, bedrooms: 2, bathrooms: 2, cleaningType: "deep" });
  const [photos, setPhotos] = useState({ living: 0, kitchen: 0, bathroom: 0, bedroom: 0, extra: 0 });
  const [est, setEst] = useState(null);
  const [submitMode, setSubmitMode] = useState("callback");

  // scroll to top on view change
  useEffect(() => { window.scrollTo(0, 0); document.querySelector("main")?.scrollTo?.(0, 0); }, [view, companyTab]);

  const goCompany = (tab = "dashboard") => { setCompanyTab(tab); setView("company"); };
  const openRequest = (r) => { setSelected(r); setCompanyTab("quotes"); };

  // Customer flow
  if (view === "landing")
    return <Landing onStart={() => setView("property")} onCompany={() => goCompany("dashboard")} />;

  if (view === "property")
    return <PropertyInfo value={quoteInput} onChange={setQuoteInput} onExit={() => setView("landing")} onNext={() => setView("photos")} />;

  if (view === "photos")
    return <PhotoUpload photos={photos} onChange={setPhotos} onBack={() => setView("property")} onExit={() => setView("landing")}
      onNext={(total) => { setEst(Rasaia.estimate({ ...quoteInput, photoCount: total })); setView("analysis"); }} />;

  if (view === "analysis")
    return <AIAnalysis onExit={() => setView("landing")} onDone={() => setView("quote")} />;

  if (view === "quote")
    return <QuoteResults est={est} onExit={() => setView("landing")} onBack={() => setView("property")}
      onSubmit={(mode) => { setSubmitMode(mode); setView("confirm"); }} />;

  if (view === "confirm")
    return <Confirmation est={est} mode={submitMode} onHome={() => setView("landing")} onCompany={() => goCompany("dashboard")} />;

  // Company portal
  if (view === "company") {
    const shared = { tab: companyTab, setTab: setCompanyTab, onExit: () => setView("landing") };
    if (companyTab === "dashboard") return <Dashboard {...shared} onOpenRequest={openRequest} />;
    if (companyTab === "requests") return <Requests {...shared} onOpenRequest={openRequest} />;
    if (companyTab === "quotes") return <QuoteManagement {...shared} request={selected} onBack={() => setCompanyTab("requests")} />;
    if (companyTab === "insights") return <Insights {...shared} />;
  }

  return <Landing onStart={() => setView("property")} onCompany={() => goCompany("dashboard")} />;
}

ReactDOM.createRoot(document.getElementById("root")).render(
  <LangProvider><App /></LangProvider>
);
