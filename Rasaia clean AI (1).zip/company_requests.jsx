/* ============================================================
   Company portal — Customer Requests (9) · Quote Management (10)
   ============================================================ */

const SVC_TO_KEY = { "Regular Cleaning": "regular", "Deep Cleaning": "deep", "Move-Out Cleaning": "moveout", "Post-Renovation Cleaning": "postreno" };
const PROP_TO_KEY = { "Apartment": "apartment", "Villa": "villa", "Townhouse": "townhouse", "Office": "office" };

/* ---------------- Screen 9: Customer Requests ---------------- */
function Requests({ tab, setTab, onExit, onOpenRequest }) {
  const { t } = useLang();
  const [filter, setFilter] = useState("all");
  const [q, setQ] = useState("");
  const filters = [
    { key: "all", label: t("All") }, { key: "pending", label: t("Pending") }, { key: "confirmed", label: t("Confirmed") },
    { key: "review", label: t("In review") }, { key: "rejected", label: t("Rejected") },
  ];
  const counts = Rasaia.REQUESTS.reduce((a, r) => { a[r.status] = (a[r.status] || 0) + 1; return a; }, {});
  const rows = Rasaia.REQUESTS.filter(r => (filter === "all" || r.status === filter) && (q === "" || r.name.toLowerCase().includes(q.toLowerCase()) || r.id.toLowerCase().includes(q.toLowerCase())));

  return (
    <CompanyShell tab={tab} setTab={setTab} onExit={onExit} title={t("Customer Requests")} subtitle={`${Rasaia.REQUESTS.length} ${t("total quotes")} · ${counts.pending || 0} ${t("awaiting action")}`}>
      <div className="card" style={{ overflow: "hidden" }}>
        <div className="row" style={{ justifyContent: "space-between", padding: "16px 20px", borderBottom: "1px solid var(--line)", flexWrap: "wrap", gap: 12 }}>
          <div className="row gap-2 wrap">
            {filters.map(f => {
              const active = filter === f.key;
              const n = f.key === "all" ? Rasaia.REQUESTS.length : (counts[f.key] || 0);
              return (
                <button key={f.key} onClick={() => setFilter(f.key)} className="row gap-2" style={{ padding: "7px 13px", borderRadius: 99, fontSize: 13, fontWeight: 600,
                  background: active ? "var(--navy)" : "var(--surface-2)", color: active ? "#fff" : "var(--ink-2)", transition: "all .12s" }}>
                  {f.label}<span style={{ fontSize: 11, opacity: .7 }}>{n}</span>
                </button>
              );
            })}
          </div>
          <div className="row gap-2" style={{ height: 40, padding: "0 14px", border: "1px solid var(--line)", borderRadius: 99, background: "var(--surface)", color: "var(--ink-3)", width: 240 }}>
            <Icon name="search" size={16} /><input value={q} onChange={e => setQ(e.target.value)} placeholder={t("Search name or reference…")} style={{ border: "none", outline: "none", background: "none", fontSize: 13.5, width: "100%" }} />
          </div>
        </div>
        {rows.length ? <RequestTable rows={rows} onOpen={onOpenRequest} /> : (
          <div className="col" style={{ alignItems: "center", padding: "60px 20px", color: "var(--ink-3)", gap: 10 }}>
            <Icon name="search" size={28} /><div style={{ fontWeight: 600 }}>{t("No requests match your filters")}</div>
          </div>
        )}
      </div>
    </CompanyShell>
  );
}

/* ---------------- Screen 10: Quote Management ---------------- */
function QuoteManagement({ tab, setTab, onExit, request, onBack }) {
  const { t } = useLang();
  const base = request || Rasaia.REQUESTS[0];
  const est = Rasaia.estimate({
    propertyType: PROP_TO_KEY[base.prop] || "apartment",
    size: base.size, bedrooms: base.beds, bathrooms: base.baths,
    cleaningType: SVC_TO_KEY[base.svc] || "deep", photoCount: 5,
  });
  const [status, setStatus] = useState(base.status);
  const [editing, setEditing] = useState(false);
  const [price, setPrice] = useState(base.price);
  const [team, setTeam] = useState(est.team);
  const [toast, setToast] = useState(null);
  const st = Rasaia.STATUS_META[status];

  const flash = (msg) => { setToast(msg); setTimeout(() => setToast(null), 2600); };
  const act = (next, msg) => { setStatus(next); setEditing(false); flash(msg); };

  return (
    <CompanyShell tab={tab} setTab={setTab} onExit={onExit} title={t("Quote Management")} subtitle={t("Review, edit and decide on AI-generated quotes")}
      action={<button className="btn btn-ghost btn-sm" onClick={onBack}><Icon name="arrowLeft" size={15} /> {t("All requests")}</button>}>

      {toast && <div className="scale-in" style={{ position: "fixed", top: 84, insetInlineEnd: 28, zIndex: 80, background: "var(--navy)", color: "#fff", padding: "13px 18px", borderRadius: 12, boxShadow: "var(--sh-lg)", fontSize: 14, fontWeight: 600 }} ><span className="row gap-2"><Icon name="check" size={16} stroke={3} /> {toast}</span></div>}

      <div style={{ display: "grid", gridTemplateColumns: "1.5fr 1fr", gap: 20, alignItems: "start" }} className="qm-grid">
        {/* LEFT: quote detail */}
        <div className="col gap-5">
          <div className="card" style={{ padding: 0, overflow: "hidden" }}>
            <div className="row" style={{ justifyContent: "space-between", padding: "22px 24px", borderBottom: "1px solid var(--line)", flexWrap: "wrap", gap: 12 }}>
              <div className="row gap-3">
                <div style={{ width: 46, height: 46, borderRadius: "50%", background: "linear-gradient(145deg,var(--blue-500),var(--ai-500))", color: "#fff", display: "grid", placeItems: "center", fontWeight: 700 }}>{base.name.split(" ").map(n => n[0]).join("")}</div>
                <div><div style={{ fontWeight: 800, fontSize: 17 }}>{base.name}</div><div className="mono muted" style={{ fontSize: 12 }}>{base.id} · {base.area}</div></div>
              </div>
              <span className={`badge ${st.cls}`} style={{ height: "fit-content" }}><span className="dot" style={{ background: "currentColor" }} />{t(st.label)}</span>
            </div>

            {/* headline */}
            <div style={{ padding: 24 }}>
              <div className="row" style={{ justifyContent: "space-between", flexWrap: "wrap", gap: 16 }}>
                <div>
                  <div className="muted" style={{ fontSize: 13 }}>{t("Recommended service")}</div>
                  <div className="t-h2" style={{ marginTop: 4 }}>{t(est.service.name)}</div>
                </div>
                <ConfidenceRing value={est.confidence} size={96} />
              </div>

              {/* editable metrics */}
              <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 12, marginTop: 22 }} className="g3">
                <div style={{ background: "var(--surface-2)", borderRadius: 12, padding: "14px 16px" }}>
                  <div className="muted mono" style={{ fontSize: 10.5, letterSpacing: ".06em" }}>{t("QUOTE PRICE")}</div>
                  {editing ? <input className="input" style={{ height: 40, marginTop: 6, fontWeight: 700 }} type="number" value={price} onChange={e => setPrice(+e.target.value)} />
                    : <div style={{ fontSize: 22, fontWeight: 800, marginTop: 4 }} className="keep-ltr">{Rasaia.fmt(price)}</div>}
                </div>
                <div style={{ background: "var(--surface-2)", borderRadius: 12, padding: "14px 16px" }}>
                  <div className="muted mono" style={{ fontSize: 10.5, letterSpacing: ".06em" }}>{t("DURATION")}</div>
                  <div style={{ fontSize: 22, fontWeight: 800, marginTop: 4 }}>~{est.durationHours}h</div>
                </div>
                <div style={{ background: "var(--surface-2)", borderRadius: 12, padding: "14px 16px" }}>
                  <div className="muted mono" style={{ fontSize: 10.5, letterSpacing: ".06em" }}>{t("TEAM SIZE")}</div>
                  {editing ? (
                    <div className="row gap-2" style={{ marginTop: 6 }}>
                      <button className="btn btn-ghost btn-sm" style={{ width: 32, padding: 0 }} onClick={() => setTeam(Math.max(1, team - 1))}>−</button>
                      <span style={{ fontSize: 20, fontWeight: 800 }}>{team}</span>
                      <button className="btn btn-ghost btn-sm" style={{ width: 32, padding: 0 }} onClick={() => setTeam(team + 1)}>+</button>
                    </div>
                  ) : <div style={{ fontSize: 22, fontWeight: 800, marginTop: 4 }}>{team}</div>}
                </div>
              </div>
              {editing && <div className="row gap-2" style={{ marginTop: 14, fontSize: 12.5, color: "var(--amber-600)" }}><Icon name="edit" size={15} /> {t("Editing overrides the AI estimate. Changes are logged.")}</div>}
            </div>

            {/* AI reasoning */}
            <div style={{ padding: "0 24px 24px" }}>
              <div className="row gap-2" style={{ marginBottom: 12 }}><Icon name="sparkle" size={16} style={{ color: "var(--ai-500)" }} /><span style={{ fontWeight: 700, fontSize: 14 }}>{t("AI reasoning")}</span></div>
              <div className="col gap-2">
                {est.reasoning.map((r, i) => (
                  <div key={i} className="row gap-3" style={{ padding: "12px 14px", background: "var(--surface-2)", borderRadius: 10 }}>
                    <span className="mono" style={{ fontSize: 11, color: "var(--blue-600)", fontWeight: 700, marginTop: 2 }}>{String(i + 1).padStart(2, "0")}</span>
                    <div><div style={{ fontWeight: 700, fontSize: 13.5 }}>{t(r.t)}</div><div className="muted" style={{ fontSize: 12.5, lineHeight: 1.5, marginTop: 2 }}>{r.d}</div></div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* RIGHT: actions + property */}
        <div className="col gap-5" style={{ position: "sticky", top: 86 }}>
          <div className="card" style={{ padding: 22 }}>
            <h3 style={{ fontSize: 15, fontWeight: 700, marginBottom: 14 }}>{t("Decision")}</h3>
            <div className="col gap-3">
              {!editing ? (
                <>
                  <button className="btn btn-block" style={{ background: "var(--green-600)", color: "#fff" }} onClick={() => act("confirmed", t("Quote approved & confirmed"))}><Icon name="check" size={17} stroke={3} /> {t("Approve quote")}</button>
                  <button className="btn btn-ghost btn-block" onClick={() => setEditing(true)}><Icon name="edit" size={16} /> {t("Edit quote")}</button>
                  <button className="btn btn-block" style={{ background: "var(--red-100)", color: "var(--red-600)" }} onClick={() => act("rejected", t("Quote rejected"))}><Icon name="close" size={16} /> {t("Reject quote")}</button>
                </>
              ) : (
                <>
                  <button className="btn btn-primary btn-block" onClick={() => act(status === "rejected" ? "review" : status, t("Quote updated"))}><Icon name="check" size={16} stroke={3} /> {t("Save changes")}</button>
                  <button className="btn btn-ghost btn-block" onClick={() => { setEditing(false); setPrice(base.price); setTeam(est.team); }}>{t("Cancel")}</button>
                </>
              )}
            </div>
            <div className="muted" style={{ fontSize: 12, marginTop: 14, lineHeight: 1.5 }}>{t("Approving notifies the customer and books the job. Rejecting sends a polite decline.")}</div>
          </div>

          <div className="card" style={{ padding: 22 }}>
            <h3 style={{ fontSize: 15, fontWeight: 700, marginBottom: 14 }}>{t("Property details")}</h3>
            <div className="col">
              {[["pin", t("Location"), base.area], ["building", t("Type"), t(base.prop)], ["ruler", t("Size"), base.size.toLocaleString() + " " + t("sq ft")], ["bed", t("Bedrooms"), base.beds], ["bath", t("Bathrooms"), base.baths], ["clock", t("Submitted"), base.when]].map((row, i) => (
                <div key={row[1]} className="row" style={{ justifyContent: "space-between", padding: "10px 0", borderTop: i ? "1px solid var(--line-2)" : "none" }}>
                  <span className="row gap-2 muted" style={{ fontSize: 13 }}><Icon name={row[0]} size={15} style={{ color: "var(--blue-500)" }} /> {row[1]}</span>
                  <span style={{ fontSize: 13, fontWeight: 700 }}>{row[2]}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
      <style>{`@media(max-width:980px){.qm-grid{grid-template-columns:1fr!important}.qm-grid>div:last-child{position:static!important}}`}</style>
    </CompanyShell>
  );
}

Object.assign(window, { Requests, QuoteManagement });
