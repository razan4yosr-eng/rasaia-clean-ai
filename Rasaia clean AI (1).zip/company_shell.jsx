/* ============================================================
   Company portal — shell, charts, Dashboard (8), Insights (11)
   ============================================================ */

const COMPANY_NAV = [
  { key: "dashboard", label: "Dashboard", icon: "dashboard" },
  { key: "requests", label: "Customer Requests", icon: "list" },
  { key: "quotes", label: "Quote Management", icon: "edit" },
  { key: "insights", label: "AI Insights", icon: "insights" },
];

function CompanyShell({ tab, setTab, onExit, title, subtitle, children, action }) {
  const { t } = useLang();
  return (
    <div style={{ display: "flex", minHeight: "100vh", background: "var(--surface-2)" }}>
      {/* Sidebar */}
      <aside className="co-sidebar" style={{ width: 252, background: "var(--surface)", borderInlineEnd: "1px solid var(--line)", display: "flex", flexDirection: "column", position: "sticky", top: 0, height: "100vh" }}>
        <div style={{ padding: "20px 20px 16px" }}><Logo size={28} /></div>
        <nav className="col" style={{ gap: 3, padding: "8px 12px", flex: 1 }}>
          <div className="mono muted" style={{ fontSize: 10.5, letterSpacing: ".1em", padding: "8px 12px 4px" }}>{t("WORKSPACE")}</div>
          {COMPANY_NAV.map(n => {
            const active = tab === n.key;
            return (
              <button key={n.key} onClick={() => setTab(n.key)} className="row gap-3" style={{ padding: "10px 12px", borderRadius: 10, width: "100%", textAlign: "start",
                background: active ? "var(--blue-50)" : "transparent", color: active ? "var(--blue-700)" : "var(--ink-2)", fontWeight: active ? 700 : 600, fontSize: 14, transition: "background .12s" }}>
                <Icon name={n.icon} size={18} /> {t(n.label)}
              </button>
            );
          })}
        </nav>
        <div style={{ padding: 12, borderTop: "1px solid var(--line)" }}>
          <div className="row gap-3" style={{ padding: "8px 10px", borderRadius: 10 }}>
            <div style={{ width: 36, height: 36, borderRadius: "50%", background: "linear-gradient(145deg, var(--blue-500), var(--ai-500))", color: "#fff", display: "grid", placeItems: "center", fontWeight: 700, fontSize: 14 }}>RA</div>
            <div className="grow"><div style={{ fontSize: 13.5, fontWeight: 700 }}>Rana Aziz</div><div className="muted" style={{ fontSize: 11.5 }}>{t("Operations lead")}</div></div>
          </div>
          <button className="btn btn-ghost btn-sm btn-block" style={{ marginTop: 8 }} onClick={onExit}><Icon name="arrowLeft" size={15} /> {t("Customer site")}</button>
        </div>
      </aside>

      {/* Main */}
      <div style={{ flex: 1, minWidth: 0, display: "flex", flexDirection: "column" }}>
        <header style={{ position: "sticky", top: 0, zIndex: 30, background: "rgba(255,255,255,.85)", backdropFilter: "blur(12px)", borderBottom: "1px solid var(--line)" }}>
          <div className="row" style={{ height: 70, padding: "0 28px", justifyContent: "space-between", gap: 16 }}>
            <div><h1 style={{ fontSize: 21, fontWeight: 800, letterSpacing: "-.015em" }}>{title}</h1>{subtitle && <div className="muted" style={{ fontSize: 13, marginTop: 2 }}>{subtitle}</div>}</div>
            <div className="row gap-3">
              <LanguageToggle compact />
              <div className="row gap-2 co-search" style={{ height: 42, padding: "0 14px", border: "1px solid var(--line)", borderRadius: 99, background: "var(--surface)", color: "var(--ink-3)", width: 220 }}>
                <Icon name="search" size={16} /><input placeholder={t("Search requests…")} style={{ border: "none", outline: "none", background: "none", fontSize: 13.5, width: "100%" }} />
              </div>
              <button className="row" style={{ width: 42, height: 42, borderRadius: 99, border: "1px solid var(--line)", background: "var(--surface)", justifyContent: "center", position: "relative" }}><Icon name="bell" size={18} /><span style={{ position: "absolute", top: 9, insetInlineEnd: 10, width: 7, height: 7, borderRadius: "50%", background: "var(--red-600)", border: "1.5px solid #fff" }} /></button>
              {action}
            </div>
          </div>
        </header>
        <div style={{ padding: 28, flex: 1 }}>{children}</div>
      </div>
      <style>{`@media(max-width:860px){.co-sidebar{display:none!important}.co-search{display:none!important}}`}</style>
    </div>
  );
}

/* ---------------- Charts ---------------- */
function BarTrend({ data }) {
  const max = Math.max(...data);
  const labels = ["J","F","M","A","M","J","J","A","S","O","N","D"];
  return (
    <div className="row" style={{ alignItems: "flex-end", gap: 8, height: 170, paddingTop: 8 }}>
      {data.map((d, i) => (
        <div key={i} className="col" style={{ flex: 1, alignItems: "center", gap: 8, height: "100%", justifyContent: "flex-end" }}>
          <div title={d} style={{ width: "100%", maxWidth: 30, height: `${(d / max) * 100}%`, borderRadius: "6px 6px 3px 3px",
            background: i === data.length - 1 ? "linear-gradient(180deg, var(--blue-500), var(--blue-700))" : "var(--blue-100)" }} />
          <span className="mono muted" style={{ fontSize: 10 }}>{labels[i]}</span>
        </div>
      ))}
    </div>
  );
}

function Donut({ data, size = 168 }) {
  const { t } = useLang();
  const r = (size - 26) / 2, c = 2 * Math.PI * r, cx = size / 2;
  let off = 0;
  const total = data.reduce((a, b) => a + b.pct, 0);
  return (
    <div className="row gap-5" style={{ alignItems: "center", flexWrap: "wrap" }}>
      <div style={{ position: "relative", width: size, height: size, flexShrink: 0 }}>
        <svg width={size} height={size} style={{ transform: "rotate(-90deg)" }}>
          {data.map((d, i) => {
            const len = (d.pct / total) * c;
            const seg = <circle key={i} cx={cx} cy={cx} r={r} fill="none" stroke={d.color} strokeWidth="14" strokeLinecap="round" strokeDasharray={`${Math.max(0, len - 4)} ${c}`} strokeDashoffset={-off} style={{ transition: "stroke-dasharray .6s" }} />;
            off += len; return seg;
          })}
        </svg>
        <div style={{ position: "absolute", inset: 0, display: "grid", placeItems: "center", textAlign: "center" }}>
          <div><div style={{ fontSize: 26, fontWeight: 800 }}>{data[0].pct}%</div><div className="muted" style={{ fontSize: 11 }}>{t(data[0].name).split(" ")[0]}</div></div>
        </div>
      </div>
      <div className="col gap-3" style={{ flex: 1, minWidth: 180 }}>
        {data.map(d => (
          <div key={d.name} className="row" style={{ justifyContent: "space-between" }}>
            <span className="row gap-2" style={{ fontSize: 13, fontWeight: 600 }}><span style={{ width: 10, height: 10, borderRadius: 3, background: d.color }} /> {t(d.name)}</span>
            <span className="mono" style={{ fontSize: 13, fontWeight: 600 }}>{d.pct}%</span>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ---------------- Screen 8: Dashboard ---------------- */
function Dashboard({ tab, setTab, onExit, onOpenRequest }) {
  const { t } = useLang();
  const k = Rasaia.KPIS;
  return (
    <CompanyShell tab={tab} setTab={setTab} onExit={onExit} title={t("Dashboard")} subtitle={t("Quotation activity across your business")}
      action={<button className="btn btn-primary btn-sm" onClick={() => setTab("requests")}><Icon name="list" size={16} /> {t("All requests")}</button>}>
      {/* KPI row */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(5,1fr)", gap: 16 }} className="kpi-grid">
        <StatCard icon="doc" label={t("Total quotes generated")} value={k.totalQuotes.toLocaleString()} delta="+12%" />
        <StatCard icon="clock" label={t("Pending requests")} value={k.pending} delta={"8 " + t("new")} deltaTone="amber" accent="var(--amber-600)" />
        <StatCard icon="check" label={t("Confirmed requests")} value={k.confirmed} delta="+9%" />
        <StatCard icon="money" label={t("Average quote value")} value={Rasaia.fmt(k.avgValue)} delta="+4%" />
        <StatCard icon="star" label={t("Most requested")} value={t(k.topService).split(" ")[0]} sub={t(k.topService)} accent="var(--ai-500)" />
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1.5fr 1fr", gap: 16, marginTop: 16 }} className="dash-grid">
        <div className="card" style={{ padding: 24 }}>
          <div className="row" style={{ justifyContent: "space-between", marginBottom: 10 }}>
            <div><h3 className="t-h3">{t("Quotes generated")}</h3><div className="muted" style={{ fontSize: 13 }}>{t("Last 12 months")}</div></div>
            <Badge kind="green" dot>+18% YoY</Badge>
          </div>
          <BarTrend data={Rasaia.TREND} />
        </div>
        <div className="card" style={{ padding: 24 }}>
          <h3 className="t-h3" style={{ marginBottom: 18 }}>{t("Service mix")}</h3>
          <Donut data={Rasaia.SERVICE_MIX} />
        </div>
      </div>

      {/* Recent requests */}
      <div className="card" style={{ marginTop: 16, overflow: "hidden" }}>
        <div className="row" style={{ justifyContent: "space-between", padding: "20px 24px", borderBottom: "1px solid var(--line)" }}>
          <h3 className="t-h3">{t("Recent requests")}</h3>
          <button className="btn btn-soft btn-sm" onClick={() => setTab("requests")}>{t("View all")} <Icon name="arrowRight" size={15} /></button>
        </div>
        <RequestTable rows={Rasaia.REQUESTS.slice(0, 5)} onOpen={onOpenRequest} compact />
      </div>

      <style>{`@media(max-width:1100px){.kpi-grid{grid-template-columns:repeat(2,1fr)!important}.dash-grid{grid-template-columns:1fr!important}}`}</style>
    </CompanyShell>
  );
}

/* shared table (used by dashboard + requests) */
function RequestTable({ rows, onOpen, compact }) {
  const { t } = useLang();
  return (
    <div style={{ overflowX: "auto" }}>
      <table style={{ width: "100%", borderCollapse: "collapse", minWidth: 720 }}>
        <thead>
          <tr style={{ textAlign: "start" }}>
            {[t("Customer"), t("Property"), t("Services"), t("Est. price"), t("Confidence"), t("Status"), ""].map((h, i) => (
              <th key={i} className="mono" style={{ fontSize: 10.5, letterSpacing: ".06em", color: "var(--ink-3)", fontWeight: 600, padding: "12px 24px", borderBottom: "1px solid var(--line)", textTransform: "uppercase", background: "var(--surface-2)", textAlign: "start" }}>{h}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map(r => {
            const st = Rasaia.STATUS_META[r.status];
            return (
              <tr key={r.id} onClick={() => onOpen(r)} className="req-row" style={{ cursor: "pointer", transition: "background .12s" }}>
                <td style={{ padding: "14px 24px", borderBottom: "1px solid var(--line-2)" }}>
                  <div className="row gap-3">
                    <div style={{ width: 34, height: 34, borderRadius: "50%", background: "var(--surface-3)", color: "var(--ink-2)", display: "grid", placeItems: "center", fontWeight: 700, fontSize: 12.5, flexShrink: 0 }}>{r.name.split(" ").map(n => n[0]).join("")}</div>
                    <div><div style={{ fontWeight: 700, fontSize: 14 }}>{r.name}</div><div className="mono muted" style={{ fontSize: 11.5 }}>{r.id} · {r.when}</div></div>
                  </div>
                </td>
                <td style={{ padding: "14px 24px", borderBottom: "1px solid var(--line-2)", fontSize: 13.5 }}><div style={{ fontWeight: 600 }}>{t(r.prop)}</div><div className="muted" style={{ fontSize: 12 }}>{r.area}</div></td>
                <td style={{ padding: "14px 24px", borderBottom: "1px solid var(--line-2)", fontSize: 13.5, fontWeight: 600 }}>{t(r.svc)}</td>
                <td style={{ padding: "14px 24px", borderBottom: "1px solid var(--line-2)", fontSize: 14, fontWeight: 700 }} ><span className="keep-ltr">{Rasaia.fmt(r.price)}</span></td>
                <td style={{ padding: "14px 24px", borderBottom: "1px solid var(--line-2)" }}>
                  <div className="row gap-2"><div style={{ width: 42, height: 6, borderRadius: 99, background: "var(--surface-3)", overflow: "hidden" }}><div style={{ width: r.conf + "%", height: "100%", background: r.conf >= 90 ? "var(--green-600)" : r.conf >= 82 ? "var(--blue-500)" : "var(--amber-600)" }} /></div><span className="mono" style={{ fontSize: 12, fontWeight: 600 }}>{r.conf}%</span></div>
                </td>
                <td style={{ padding: "14px 24px", borderBottom: "1px solid var(--line-2)" }}><span className={`badge ${st.cls}`}>{t(st.label)}</span></td>
                <td style={{ padding: "14px 24px", borderBottom: "1px solid var(--line-2)", textAlign: "end" }}><Icon name="arrowRight" size={16} style={{ color: "var(--ink-3)" }} /></td>
              </tr>
            );
          })}
        </tbody>
      </table>
      <style>{`.req-row:hover{background:var(--surface-2)}`}</style>
    </div>
  );
}

/* ---------------- Screen 11: AI Insights ---------------- */
function Insights({ tab, setTab, onExit }) {
  const { t } = useLang();
  const toneMap = { blue: { bg: "var(--blue-50)", fg: "var(--blue-600)" }, green: { bg: "var(--green-100)", fg: "var(--green-600)" }, amber: { bg: "var(--amber-100)", fg: "var(--amber-600)" } };
  return (
    <CompanyShell tab={tab} setTab={setTab} onExit={onExit} title={t("AI Insights")} subtitle={t("What the quotation engine is learning about your business")}>
      {/* top metrics */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 16 }} className="kpi-grid">
        <StatCard icon="star" label={t("Most requested service")} value={t("Deep Cleaning").split(" ")[0]} sub={t("Deep Cleaning") + " · 41%"} accent="var(--ai-500)" />
        <StatCard icon="ruler" label={t("Average property size")} value="1,640" sub={t("sq ft across all quotes")} />
        <StatCard icon="trend" label={t("Deep Cleaning demand")} value="+18%" delta="30d" deltaTone="green" />
        <StatCard icon="money" label={t("Average quote value")} value={Rasaia.fmt(Rasaia.KPIS.avgValue)} delta="+4%" />
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, marginTop: 16 }} className="dash-grid">
        <div className="card" style={{ padding: 24 }}>
          <h3 className="t-h3" style={{ marginBottom: 18 }}>{t("Service demand breakdown")}</h3>
          <Donut data={Rasaia.SERVICE_MIX} />
        </div>
        <div className="card" style={{ padding: 24 }}>
          <div className="row" style={{ justifyContent: "space-between", marginBottom: 10 }}><h3 className="t-h3">{t("Quote volume trend")}</h3><Badge kind="blue">{t("Monthly")}</Badge></div>
          <BarTrend data={Rasaia.TREND} />
        </div>
      </div>

      {/* AI generated insights */}
      <div className="row gap-3" style={{ margin: "26px 0 16px" }}>
        <div style={{ width: 34, height: 34, borderRadius: 10, background: "var(--ai-100)", color: "var(--ai-500)", display: "grid", placeItems: "center" }}><Icon name="sparkle" size={18} /></div>
        <div><h2 className="t-h3">{t("AI-generated business insights")}</h2><div className="muted" style={{ fontSize: 13 }}>{t("Updated automatically from quotation data")}</div></div>
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 16 }} className="g3">
        {Rasaia.INSIGHTS.map((ins, i) => {
          const tone = toneMap[ins.tone];
          return (
            <div key={i} className="card" style={{ padding: 22, borderTop: `3px solid ${tone.fg}` }}>
              <div className="row gap-2" style={{ marginBottom: 12 }}><div style={{ width: 30, height: 30, borderRadius: 9, background: tone.bg, color: tone.fg, display: "grid", placeItems: "center" }}><Icon name="bolt" size={16} /></div><Badge kind="ai">{t("AI insight")}</Badge></div>
              <h3 style={{ fontSize: 15.5, fontWeight: 700, lineHeight: 1.3 }}>{t(ins.title)}</h3>
              <p className="muted" style={{ fontSize: 13.5, lineHeight: 1.55, marginTop: 8 }}>{t(ins.body)}</p>
            </div>
          );
        })}
      </div>
      <style>{`@media(max-width:1100px){.kpi-grid{grid-template-columns:repeat(2,1fr)!important}.dash-grid,.g3{grid-template-columns:1fr!important}}`}</style>
    </CompanyShell>
  );
}

Object.assign(window, { CompanyShell, Dashboard, Insights, RequestTable, BarTrend, Donut, COMPANY_NAV });
