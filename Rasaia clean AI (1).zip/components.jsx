/* ============================================================
   Rasaia Clean AI — Shared UI components
   ============================================================ */
const { useState, useEffect, useRef } = React;

/* ---------------- Icons (stroke, 24 grid) ---------------- */
const PATHS = {
  sparkle: "M12 3l1.8 4.6L18.4 9.4 13.8 11.2 12 15.8 10.2 11.2 5.6 9.4 10.2 7.6z M19 14l.8 2 2 .8-2 .8-.8 2-.8-2-2-.8 2-.8z",
  arrowRight: "M5 12h14 M13 6l6 6-6 6",
  arrowLeft: "M19 12H5 M11 18l-6-6 6-6",
  check: "M5 13l4 4L19 7",
  building: "M5 21V5a2 2 0 012-2h7a2 2 0 012 2v16 M9 7h2 M9 11h2 M9 15h2 M16 21h3a0 0 0 000 0V11a2 2 0 00-2-2h-1",
  home: "M4 11l8-7 8 7 M6 10v9a1 1 0 001 1h10a1 1 0 001-1v-9 M10 20v-5h4v5",
  townhouse: "M3 21V9l5-3 M8 21V6l6-3 7 4v14 M11 11h2 M11 15h2 M17 11h0 M17 15h0",
  briefcase: "M3 9a2 2 0 012-2h14a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2z M9 7V5a2 2 0 012-2h2a2 2 0 012 2v2 M3 13h18",
  upload: "M12 16V4 M7 9l5-5 5 5 M5 16v2a2 2 0 002 2h10a2 2 0 002-2v-2",
  image: "M4 5a1 1 0 011-1h14a1 1 0 011 1v14a1 1 0 01-1 1H5a1 1 0 01-1-1z M8.5 11a1.5 1.5 0 100-3 1.5 1.5 0 000 3 M4 17l4.5-4 4 3.5L16 12l4 4",
  clock: "M12 7v5l3 2 M12 21a9 9 0 100-18 9 9 0 000 18z",
  users: "M9 11a3.5 3.5 0 100-7 3.5 3.5 0 000 7z M3 20v-1a5 5 0 015-5h2a5 5 0 015 5v1 M16 4.5a3.5 3.5 0 010 6.8 M21 20v-1a5 5 0 00-3.5-4.7",
  tag: "M4 4h7l9 9-7 7-9-9z M8.5 8.5h0",
  shield: "M12 3l8 3v6c0 4.5-3.2 7.8-8 9-4.8-1.2-8-4.5-8-9V6z M9 12l2 2 4-4",
  doc: "M7 3h7l5 5v13a0 0 0 010 0H7a1 1 0 01-1-1V4a1 1 0 011-1z M14 3v5h5 M9 13h6 M9 17h6",
  phone: "M5 4h3l1.5 5-2 1.5a12 12 0 005 5l1.5-2 5 1.5v3a1 1 0 01-1 1A16 16 0 014 6a1 1 0 011-2z",
  headset: "M4 13v-1a8 8 0 0116 0v1 M4 13h2a1 1 0 011 1v4a1 1 0 01-1 1H5a1 1 0 01-1-1z M20 13h-2a1 1 0 00-1 1v4a1 1 0 001 1 M17 19a4 4 0 01-4 2",
  chat: "M5 4h14a1 1 0 011 1v10a1 1 0 01-1 1H9l-4 4V5a1 1 0 011-1z",
  send: "M5 12l15-7-7 15-2.5-5.5z",
  dashboard: "M4 4h7v7H4z M13 4h7v4h-7z M13 11h7v9h-7z M4 14h7v6H4z",
  list: "M8 6h13 M8 12h13 M8 18h13 M3.5 6h0 M3.5 12h0 M3.5 18h0",
  edit: "M4 20h4l10-10-4-4L4 16z M14 6l4 4",
  insights: "M4 19V5 M4 19h16 M8 16l3.5-4 3 2.5L20 8",
  trend: "M4 15l5-5 4 3 7-8 M14 5h6v6",
  bolt: "M13 3L5 14h6l-1 7 8-11h-6z",
  star: "M12 3l2.5 6.2 6.5.5-5 4.3 1.6 6.5L12 17l-5.6 3.5L8 14 3 9.7l6.5-.5z",
  close: "M6 6l12 12 M18 6L6 18",
  menu: "M4 7h16 M4 12h16 M4 17h16",
  plus: "M12 5v14 M5 12h14",
  money: "M12 3v18 M16 7H10a2.5 2.5 0 000 5h4a2.5 2.5 0 010 5H8",
  pin: "M12 21s-7-6.2-7-11A7 7 0 0112 3a7 7 0 017 7c0 4.8-7 11-7 11z M12 12a2 2 0 100-4 2 2 0 000 4z",
  ruler: "M3 7l4-4 14 14-4 4z M7 7l2 2 M11 11l2 2 M15 15l2 2",
  bed: "M3 18v-6a2 2 0 012-2h14a2 2 0 012 2v6 M3 14h18 M7 10V8a1 1 0 011-1h3a1 1 0 011 1v2",
  bath: "M4 12h16v3a3 3 0 01-3 3H7a3 3 0 01-3-3z M6 12V6a2 2 0 012-2 2 2 0 012 2 M6 19l-1 2 M18 19l1 2",
  filter: "M4 5h16 M7 12h10 M10 19h4",
  bell: "M6 10a6 6 0 1112 0c0 5 2 6 2 6H4s2-1 2-6 M10 21h4",
  search: "M11 11m-7 0a7 7 0 1014 0 7 7 0 10-14 0 M21 21l-4-4",
};

function Icon({ name, size = 20, stroke = 2, className = "", style = {} }) {
  const d = PATHS[name];
  const directional = name === "arrowRight" || name === "arrowLeft" || name === "send";
  const cls = (directional ? "flip-rtl " : "") + className;
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none"
      stroke="currentColor" strokeWidth={stroke} strokeLinecap="round" strokeLinejoin="round"
      className={cls} style={style} aria-hidden="true">
      {d.split(" M").map((seg, i) => <path key={i} d={(i === 0 ? "" : "M") + seg} />)}
    </svg>
  );
}

/* ---------------- Logo ---------------- */
function Logo({ size = 30, light = false, showText = true }) {
  const fg = light ? "#fff" : "var(--navy)";
  return (
    <div className="row gap-3" style={{ alignItems: "center" }}>
      <div style={{
        width: size, height: size, borderRadius: size * 0.3,
        background: "linear-gradient(145deg, var(--blue-500), var(--blue-700))",
        display: "grid", placeItems: "center", color: "#fff",
        boxShadow: "0 4px 12px rgba(35,71,217,.35)", flexShrink: 0,
      }}>
        <Icon name="sparkle" size={size * 0.62} stroke={0} style={{ fill: "#fff", stroke: "none" }} />
      </div>
      {showText && (
        <div style={{ lineHeight: 1, color: fg }}>
          <div style={{ fontWeight: 800, fontSize: size * 0.56, letterSpacing: "-.02em" }}>Rasaia</div>
          <div className="mono" style={{ fontSize: size * 0.3, letterSpacing: ".18em", color: light ? "rgba(255,255,255,.7)" : "var(--blue-600)", marginTop: 3, textTransform: "uppercase" }}>Clean AI</div>
        </div>
      )}
    </div>
  );
}

/* ---------------- Badge ---------------- */
function Badge({ children, kind = "gray", dot = false }) {
  return (
    <span className={`badge badge-${kind}`}>
      {dot && <span className="dot" style={{ background: "currentColor" }} />}
      {children}
    </span>
  );
}

/* ---------------- Progress steps (customer wizard) ---------------- */
function ProgressSteps({ steps, current }) {
  return (
    <div className="row" style={{ gap: 0, alignItems: "center" }}>
      {steps.map((s, i) => {
        const done = i < current, active = i === current;
        return (
          <React.Fragment key={s}>
            <div className="row gap-2" style={{ alignItems: "center" }}>
              <div style={{
                width: 26, height: 26, borderRadius: "50%", flexShrink: 0,
                display: "grid", placeItems: "center", fontSize: 12.5, fontWeight: 700,
                background: done ? "var(--blue-600)" : active ? "var(--blue-600)" : "var(--surface-3)",
                color: done || active ? "#fff" : "var(--ink-3)",
                border: active ? "3px solid var(--blue-100)" : "none",
                transition: "all .25s",
              }}>
                {done ? <Icon name="check" size={14} stroke={3} /> : i + 1}
              </div>
              <span style={{ fontSize: 13, fontWeight: active ? 700 : 500, color: active ? "var(--ink)" : "var(--ink-3)", whiteSpace: "nowrap" }}>{s}</span>
            </div>
            {i < steps.length - 1 && (
              <div style={{ flex: 1, height: 2, margin: "0 12px", minWidth: 18,
                background: done ? "var(--blue-300)" : "var(--line)", borderRadius: 2, transition: "background .25s" }} />
            )}
          </React.Fragment>
        );
      })}
    </div>
  );
}

/* ---------------- Confidence ring ---------------- */
function ConfidenceRing({ value, size = 132 }) {
  const r = (size - 16) / 2, c = 2 * Math.PI * r;
  const shown = value;
  return (
    <div style={{ position: "relative", width: size, height: size }}>
      <svg width={size} height={size} style={{ transform: "rotate(-90deg)" }}>
        <circle cx={size/2} cy={size/2} r={r} fill="none" stroke="var(--surface-3)" strokeWidth="9" />
        <circle cx={size/2} cy={size/2} r={r} fill="none" stroke="url(#cg)" strokeWidth="9" strokeLinecap="round"
          strokeDasharray={c} strokeDashoffset={c - (shown/100)*c} style={{ transition: "stroke-dashoffset .1s" }} />
        <defs><linearGradient id="cg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor="var(--blue-500)" /><stop offset="1" stopColor="var(--ai-500)" /></linearGradient></defs>
      </svg>
      <div style={{ position: "absolute", inset: 0, display: "grid", placeItems: "center", textAlign: "center" }}>
        <div>
          <div style={{ fontSize: size * 0.27, fontWeight: 800, letterSpacing: "-.02em", lineHeight: 1 }}>{shown}<span style={{ fontSize: size*0.13 }}>%</span></div>
          <div className="mono" style={{ fontSize: 10, color: "var(--ink-3)", letterSpacing: ".1em", marginTop: 4 }}>CONFIDENCE</div>
        </div>
      </div>
    </div>
  );
}

/* ---------------- Stat / metric card ---------------- */
function StatCard({ icon, label, value, delta, deltaTone = "green", accent = "var(--blue-600)", sub }) {
  return (
    <div className="card" style={{ padding: 22, display: "flex", flexDirection: "column", gap: 14 }}>
      <div className="row" style={{ justifyContent: "space-between", alignItems: "flex-start" }}>
        <div style={{ width: 42, height: 42, borderRadius: 12, background: "var(--blue-50)", color: accent, display: "grid", placeItems: "center" }}>
          <Icon name={icon} size={21} />
        </div>
        {delta && <span className={`badge badge-${deltaTone}`} style={{ fontSize: 12 }}>{delta}</span>}
      </div>
      <div>
        <div style={{ fontSize: 30, fontWeight: 800, letterSpacing: "-.02em", lineHeight: 1.1 }}>{value}</div>
        <div className="muted" style={{ fontSize: 13.5, marginTop: 5 }}>{label}</div>
        {sub && <div className="muted" style={{ fontSize: 12, marginTop: 2 }}>{sub}</div>}
      </div>
    </div>
  );
}

/* ---------------- Photo placeholder tile (striped) ---------------- */
function PhotoTile({ label, filled, onClick, big }) {
  return (
    <button onClick={onClick} style={{
      position: "relative", aspectRatio: big ? "16/10" : "1/1", borderRadius: 14, overflow: "hidden",
      border: filled ? "1px solid var(--line)" : "1.5px dashed #C5D0E4",
      background: filled
        ? "repeating-linear-gradient(135deg, #E9EEF8 0 12px, #E2E9F5 12px 24px)"
        : "var(--surface-2)",
      display: "grid", placeItems: "center", cursor: "pointer", transition: "border-color .15s, background .15s", width: "100%",
    }}
    onMouseEnter={e => { if (!filled) e.currentTarget.style.borderColor = "var(--blue-400)"; }}
    onMouseLeave={e => { if (!filled) e.currentTarget.style.borderColor = "#C5D0E4"; }}>
      {filled ? (
        <div className="mono" style={{ fontSize: 11, color: "var(--ink-3)", background: "rgba(255,255,255,.85)", padding: "4px 9px", borderRadius: 6 }}>{label} photo</div>
      ) : (
        <div className="col" style={{ alignItems: "center", gap: 7, color: "var(--ink-3)" }}>
          <Icon name="plus" size={20} />
          <span style={{ fontSize: 12.5, fontWeight: 600 }}>Add photo</span>
        </div>
      )}
    </button>
  );
}

Object.assign(window, {
  Icon, Logo, Badge, ProgressSteps, ConfidenceRing, StatCard, PhotoTile,
});
