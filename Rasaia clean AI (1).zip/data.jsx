/* ============================================================
   Rasaia Clean AI — Sample data + AI estimation engine
   Exposes: window.Rasaia = { CURRENCY, fmt, estimate, ... }
   ============================================================ */

const CURRENCY = "AED";
const fmt = (n) => CURRENCY + " " + Math.round(n).toLocaleString("en-US");

/* ---------- Service catalog ---------- */
const SERVICES = {
  regular:   { key: "regular",   name: "Regular Cleaning",        blurb: "Routine upkeep of living spaces and surfaces.",            rate: 0.85, hours: 1.0, complexity: "Standard" },
  deep:      { key: "deep",      name: "Deep Cleaning",           blurb: "Detailed top-to-bottom clean incl. build-up and grime.",  rate: 1.55, hours: 1.7, complexity: "Elevated" },
  moveout:   { key: "moveout",   name: "Move-Out Cleaning",       blurb: "Handover-ready clean for tenancy and inspections.",       rate: 1.85, hours: 2.0, complexity: "High"     },
  postreno:  { key: "postreno",  name: "Post-Renovation Cleaning",blurb: "Dust, debris and residue removal after construction.",    rate: 2.35, hours: 2.5, complexity: "Intensive"},
};

const PROPERTY_TYPES = [
  { key: "apartment", label: "Apartment",  icon: "building" },
  { key: "villa",     label: "Villa",      icon: "home" },
  { key: "townhouse", label: "Townhouse",  icon: "townhouse" },
  { key: "office",    label: "Office",     icon: "briefcase" },
];

const CLEANING_TYPES = [
  { key: "regular",  label: "Regular Cleaning",         desc: "Maintenance clean for lived-in homes" },
  { key: "deep",     label: "Deep Cleaning",            desc: "Thorough detail clean, every surface" },
  { key: "moveout",  label: "Move-Out Cleaning",        desc: "Inspection-ready handover clean" },
  { key: "postreno", label: "Post-Renovation Cleaning", desc: "Dust & debris removal after works" },
];

const PHOTO_ROOMS = [
  { key: "living",   label: "Living Room", hint: "Sofas, floors, surfaces" },
  { key: "kitchen",  label: "Kitchen",     hint: "Counters, appliances, sink" },
  { key: "bathroom", label: "Bathroom",    hint: "Tiles, fixtures, grout" },
  { key: "bedroom",  label: "Bedroom",     hint: "Floors, wardrobes, dust" },
  { key: "extra",    label: "Additional",  hint: "Balcony, hallway, other" },
];

/* ---------- The estimation engine ---------- */
function estimate(input) {
  const { propertyType = "apartment", size = 1100, bedrooms = 2, bathrooms = 2, cleaningType = "deep", photoCount = 0 } = input || {};
  const svc = SERVICES[cleaningType] || SERVICES.deep;

  // size-driven base, with room loading
  const roomLoad = bedrooms * 55 + bathrooms * 90;
  const effSize = Math.max(size, 350) + roomLoad;

  // labor hours
  let hours = (effSize / 240) * svc.hours;
  if (propertyType === "villa") hours *= 1.18;
  if (propertyType === "office") hours *= 0.92;
  hours = Math.max(2, hours);

  // team size
  let team = 1;
  if (hours > 4) team = 2;
  if (hours > 8) team = 3;
  if (hours > 13) team = 4;
  const perPerson = hours / team;
  const durationHours = Math.max(1.5, perPerson);

  // price
  const labor = effSize * svc.rate;
  const typeMult = propertyType === "villa" ? 1.15 : propertyType === "office" ? 1.05 : 1;
  const mid = labor * typeMult * 1.0;
  const low = mid * 0.9;
  const high = mid * 1.14;

  // confidence — more photos & moderate size = higher confidence
  let confidence = 78;
  confidence += Math.min(photoCount, 8) * 1.6;
  if (bedrooms <= 4 && bathrooms <= 4) confidence += 4;
  if (cleaningType === "regular") confidence += 3;
  confidence = Math.min(97, Math.round(confidence));

  const reasoning = [
    { t: "Property profile", d: `${PROPERTY_TYPES.find(p=>p.key===propertyType)?.label || "Property"} · ${size.toLocaleString()} sq ft · ${bedrooms} bed / ${bathrooms} bath. Adjusted workload of ${Math.round(effSize).toLocaleString()} effective sq ft after room weighting.` },
    { t: "Complexity class", d: `Classified as ${svc.complexity.toLowerCase()} complexity for ${svc.name.toLowerCase()}. ${cleaningType === "postreno" ? "Construction residue requires specialist dust extraction." : cleaningType === "moveout" ? "Inspection-grade finish across all fixtures." : cleaningType === "deep" ? "Detailing of grout, appliances and high-touch zones included." : "Standard surface maintenance across living areas."}` },
    { t: "Labor & duration", d: `Estimated ${hours.toFixed(1)} total labor hours, completed in ~${durationHours.toFixed(1)}h with a team of ${team}.` },
    { t: "Photo signals", d: photoCount > 0 ? `Analyzed ${photoCount} uploaded photo${photoCount>1?"s":""}; detected typical soiling consistent with the selected service.` : "No photos provided — estimate based on property data alone. Adding photos raises confidence." },
  ];

  return {
    service: svc,
    cleaningType,
    durationHours: Math.round(durationHours * 2) / 2,
    totalHours: Math.round(hours * 2) / 2,
    team,
    priceLow: low, priceHigh: high, priceMid: mid,
    confidence,
    complexity: svc.complexity,
    reasoning,
    input: { propertyType, size, bedrooms, bathrooms, cleaningType },
  };
}

/* ---------- AI assistant canned answers ---------- */
function assistantAnswer(q, est) {
  const key = q.toLowerCase();
  if (key.includes("service") || key.includes("recommend"))
    return `I recommended **${est.service.name}** because your inputs point to ${est.complexity.toLowerCase()} complexity. ${est.service.blurb} Based on the property size and room count, a lighter service would likely leave detailing gaps, while a heavier one would over-scope and raise the price unnecessarily.`;
  if (key.includes("cleaner") || key.includes("team") || key.includes("2 ") || key.includes("staff"))
    return `Your job is estimated at **${est.totalHours} total labor hours**. To finish within a single ~${est.durationHours}h window, I've assigned a team of **${est.team}**. Fewer cleaners would stretch the job across a longer day; more would idle. This balances speed and cost.`;
  if (key.includes("calculate") || key.includes("estimate calc") || key.includes("how was"))
    return `The estimate combines three signals: (1) effective area after weighting your ${est.input.bedrooms} bedrooms and ${est.input.bathrooms} bathrooms, (2) a per-sq-ft rate for ${est.service.name.toLowerCase()}, and (3) a property-type multiplier. That yields a midpoint of ${fmt(est.priceMid)}, presented as a ${fmt(est.priceLow)}–${fmt(est.priceHigh)} range to absorb on-site variation.`;
  if (key.includes("reduce") || key.includes("cheaper") || key.includes("lower"))
    return `A few ways to bring the estimate down: switch from ${est.service.name} to a lighter service tier, exclude rooms that don't need attention, or book a recurring plan for a loyalty rate. Want me to re-price a Regular Cleaning for comparison?`;
  return `Good question. This estimate is generated from your property details and photo signals. The recommended ${est.service.name.toLowerCase()} runs ~${est.durationHours}h with a team of ${est.team}, priced ${fmt(est.priceLow)}–${fmt(est.priceHigh)} at ${est.confidence}% confidence. Ask me about the service choice, team size, pricing, or how to reduce it.`;
}

/* ---------- Company-side sample data ---------- */
const REQUESTS = [
  { id: "RQ-4821", name: "Layla Haddad",   prop: "Apartment", area: "Marina Heights, Dubai",   svc: "Deep Cleaning",            price: 1180, conf: 92, status: "pending",   when: "12 min ago", beds: 2, baths: 2, size: 1150 },
  { id: "RQ-4820", name: "Omar Farouk",    prop: "Villa",     area: "Al Barsha, Dubai",        svc: "Move-Out Cleaning",        price: 2640, conf: 88, status: "pending",   when: "38 min ago", beds: 4, baths: 4, size: 3200 },
  { id: "RQ-4819", name: "Sara Mansoor",   prop: "Townhouse", area: "Jumeirah, Dubai",         svc: "Regular Cleaning",         price: 620,  conf: 95, status: "confirmed", when: "1 hr ago",  beds: 3, baths: 2, size: 1800 },
  { id: "RQ-4818", name: "Daniel Reyes",   prop: "Office",    area: "Business Bay, Dubai",     svc: "Deep Cleaning",            price: 1950, conf: 84, status: "review",    when: "2 hr ago",  beds: 0, baths: 3, size: 2600 },
  { id: "RQ-4817", name: "Aisha Karimi",   prop: "Apartment", area: "Downtown, Dubai",         svc: "Post-Renovation Cleaning", price: 2210, conf: 79, status: "pending",   when: "3 hr ago",  beds: 2, baths: 2, size: 1340 },
  { id: "RQ-4816", name: "Marcus Bauer",   prop: "Villa",     area: "Arabian Ranches, Dubai",  svc: "Deep Cleaning",            price: 2480, conf: 90, status: "confirmed", when: "5 hr ago",  beds: 5, baths: 5, size: 4100 },
  { id: "RQ-4815", name: "Priya Nair",     prop: "Apartment", area: "JLT, Dubai",              svc: "Regular Cleaning",         price: 540,  conf: 96, status: "confirmed", when: "6 hr ago",  beds: 1, baths: 1, size: 780  },
  { id: "RQ-4814", name: "Hassan Ali",     prop: "Townhouse", area: "Mirdif, Dubai",           svc: "Move-Out Cleaning",        price: 1760, conf: 86, status: "rejected",  when: "Yesterday", beds: 3, baths: 3, size: 2200 },
];

const STATUS_META = {
  pending:   { label: "Pending",   cls: "badge-amber" },
  confirmed: { label: "Confirmed", cls: "badge-green" },
  review:    { label: "In review", cls: "badge-blue" },
  rejected:  { label: "Rejected",  cls: "badge-red" },
};

const KPIS = {
  totalQuotes: 1284,
  pending: 47,
  confirmed: 612,
  avgValue: 1490,
  topService: "Deep Cleaning",
};

const SERVICE_MIX = [
  { name: "Deep Cleaning",            pct: 41, color: "var(--blue-600)" },
  { name: "Regular Cleaning",         pct: 28, color: "var(--blue-400)" },
  { name: "Move-Out Cleaning",        pct: 19, color: "var(--ai-500)" },
  { name: "Post-Renovation Cleaning", pct: 12, color: "#9DB0E8" },
];

const TREND = [38, 44, 41, 52, 49, 61, 58, 67, 72, 69, 81, 88];

const INSIGHTS = [
  { tone: "blue",  title: "Deep Cleaning demand is climbing", body: "Deep Cleaning requests rose 18% over the last 30 days and now drive 41% of all quotes — the strongest contributor to average quote value." },
  { tone: "green", title: "High-confidence quotes convert better", body: "Quotes generated at 90%+ confidence convert to confirmed bookings 2.3× more often. Encouraging photo uploads is the biggest confidence lever." },
  { tone: "amber", title: "Villas are under-quoted on labor", body: "Villa jobs run 12% longer than estimated on average. Consider raising the villa labor multiplier from 1.15 to 1.22 to protect margin." },
];

window.Rasaia = {
  CURRENCY, fmt, estimate, assistantAnswer,
  SERVICES, PROPERTY_TYPES, CLEANING_TYPES, PHOTO_ROOMS,
  REQUESTS, STATUS_META, KPIS, SERVICE_MIX, TREND, INSIGHTS,
};
