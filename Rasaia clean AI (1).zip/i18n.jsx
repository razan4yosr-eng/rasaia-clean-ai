/* ============================================================
   Rasaia Clean AI — Internationalization (EN / AR + RTL)
   Keyed by English source string; AR falls back to EN if missing.
   ============================================================ */
const { createContext, useContext } = React;

/* ---- Arabic dictionary (English source -> Arabic) ---- */
const AR = {
  // Nav / global
  "How it works": "كيف يعمل",
  "Benefits": "المزايا",
  "Services": "الخدمات",
  "Business portal": "بوابة الأعمال",
  "Start estimate": "ابدأ التقدير",
  "Start your estimate": "ابدأ التقدير",
  "View business portal": "عرض بوابة الأعمال",
  "Exit": "خروج",
  "Back": "رجوع",
  "Back to home": "العودة للرئيسية",
  "Done": "تم",
  "Cancel": "إلغاء",
  "Continue to photos": "المتابعة إلى الصور",
  "English": "English",
  "Arabic": "العربية",

  // Hero
  "AI-powered cleaning quotations": "عروض أسعار تنظيف مدعومة بالذكاء الاصطناعي",
  "AI estimate ready": "التقدير جاهز",
  "Recommended service": "الخدمة الموصى بها",
  "Deep Cleaning": "تنظيف عميق",
  "ESTIMATED RANGE": "النطاق التقديري",
  "Duration": "المدة",
  "~4.5 hrs": "~4.5 ساعة",
  "Team": "الفريق",
  "2 cleaners": "عاملان",
  "Get an instant cleaning estimate in": "احصل على تقدير تنظيف فوري في",
  "under 2 minutes": "أقل من دقيقتين",
  "Rasaia Clean AI turns property details and a handful of photos into a precise, consistent quotation — service, labor, duration and price — without a single WhatsApp message.":
    "يحوّل رسايا كلين الذكاء الاصطناعي تفاصيل العقار وبعض الصور إلى عرض سعر دقيق وثابت — الخدمة والعمالة والمدة والسعر — دون أي رسالة واتساب.",
  "quotes generated": "عرض سعر تم إنشاؤه",
  "average time to quote": "متوسط زمن التسعير",
  "estimate accuracy": "دقة التقدير",
  "Built for cleaning companies that quote at scale": "مصمم لشركات التنظيف التي تسعّر على نطاق واسع",
  "Residential": "سكني",
  "Commercial": "تجاري",
  "Move-out & handover": "إخلاء وتسليم",
  "Post-renovation": "ما بعد التجديد",

  // How it works
  "From property to priced quote in three steps": "من العقار إلى عرض سعر مسعّر في ثلاث خطوات",
  "Describe the property": "صف العقار",
  "Type, size, bedrooms, bathrooms and the cleaning needed.": "النوع والحجم وغرف النوم والحمامات ونوع التنظيف المطلوب.",
  "Upload a few photos": "ارفع بعض الصور",
  "Living room, kitchen, bathrooms — anything that helps.": "غرفة المعيشة والمطبخ والحمامات — أي شيء يساعد.",
  "Get an instant quote": "احصل على عرض سعر فوري",
  "Service, duration, team size and a clear price range.": "الخدمة والمدة وحجم الفريق ونطاق سعر واضح.",

  // Benefits
  "Why Rasaia": "لماذا رسايا",
  "Stop guessing. Start quoting with confidence.": "توقف عن التخمين. ابدأ التسعير بثقة.",
  "Manual quotes are slow and inconsistent — two employees, two prices. Rasaia standardizes the entire process behind one AI engine.":
    "العروض اليدوية بطيئة وغير متسقة — موظفان، سعران. توحّد رسايا العملية بأكملها خلف محرك ذكاء اصطناعي واحد.",
  "Try it now": "جرّبه الآن",
  "Instant, not hours later": "فوري، وليس بعد ساعات",
  "Replace back-and-forth WhatsApp threads with a quote generated the moment a customer submits.":
    "استبدل محادثات واتساب المتكررة بعرض سعر يُنشأ لحظة إرسال العميل لطلبه.",
  "Consistent every time": "متسق في كل مرة",
  "The same property always gets the same estimate — no more variance between employees.":
    "العقار نفسه يحصل دائمًا على التقدير نفسه — لا تباين بين الموظفين.",
  "Smarter with every photo": "أذكى مع كل صورة",
  "AI reads property photos to refine complexity, labor and pricing — and shows its reasoning.":
    "يقرأ الذكاء الاصطناعي صور العقار لتحسين التعقيد والعمالة والتسعير — ويوضح أسبابه.",
  "Protect your margins": "احمِ هوامش ربحك",
  "Transparent labor and team-size logic keeps every quote priced to win without underselling.":
    "منطق شفاف للعمالة وحجم الفريق يبقي كل عرض مسعّرًا للفوز دون بيع بأقل من القيمة.",

  // Services
  "Services we price": "الخدمات التي نسعّرها",
  "Every cleaning type, one engine": "كل أنواع التنظيف، محرك واحد",
  "Get a quote": "احصل على عرض سعر",
  "From": "ابتداءً من",
  "Regular Cleaning": "تنظيف عادي",
  "Move-Out Cleaning": "تنظيف الإخلاء",
  "Post-Renovation Cleaning": "تنظيف ما بعد التجديد",
  "Routine upkeep of living spaces and surfaces.": "صيانة روتينية للمساحات المعيشية والأسطح.",
  "Detailed top-to-bottom clean incl. build-up and grime.": "تنظيف تفصيلي شامل يشمل التراكمات والأوساخ.",
  "Handover-ready clean for tenancy and inspections.": "تنظيف جاهز للتسليم للإيجار والمعاينات.",
  "Dust, debris and residue removal after construction.": "إزالة الغبار والركام والبقايا بعد البناء.",
  "Standard": "قياسي",
  "Elevated": "مرتفع",
  "High": "عالٍ",
  "Intensive": "مكثّف",

  // CTA / footer
  "Your next quote is 2 minutes away": "عرض سعرك التالي على بُعد دقيقتين",
  "No sign-up required to try. Generate a full AI quotation and see exactly how Rasaia thinks.":
    "لا حاجة للتسجيل للتجربة. أنشئ عرض سعر كامل بالذكاء الاصطناعي وشاهد كيف تفكّر رسايا.",
  "Start your free estimate": "ابدأ تقديرك المجاني",
  "© 2026 Rasaia Clean AI · Quotation intelligence for cleaning companies":
    "© 2026 رسايا كلين الذكاء الاصطناعي · ذكاء التسعير لشركات التنظيف",

  // Wizard steps
  "Property": "العقار",
  "Photos": "الصور",
  "Analysis": "التحليل",
  "Quote": "عرض السعر",

  // Property info
  "Step 1 of 4": "الخطوة 1 من 4",
  "Step 2 of 4": "الخطوة 2 من 4",
  "Tell us about the property": "أخبرنا عن العقار",
  "The more accurate the details, the tighter your AI estimate.": "كلما دقّت التفاصيل، زاد دقة تقدير الذكاء الاصطناعي.",
  "Property type": "نوع العقار",
  "Apartment": "شقة",
  "Villa": "فيلا",
  "Townhouse": "تاون هاوس",
  "Office": "مكتب",
  "Property size": "مساحة العقار",
  "sq ft": "قدم²",
  "Bedrooms": "غرف النوم",
  "Bathrooms": "الحمامات",
  "Cleaning type": "نوع التنظيف",
  "Maintenance clean for lived-in homes": "تنظيف صيانة للمنازل المأهولة",
  "Thorough detail clean, every surface": "تنظيف تفصيلي شامل لكل سطح",
  "Inspection-ready handover clean": "تنظيف تسليم جاهز للمعاينة",
  "Dust & debris removal after works": "إزالة الغبار والركام بعد الأعمال",

  // Photo upload
  "Add photos for a sharper estimate": "أضف صورًا لتقدير أدق",
  "Optional, but photos let the AI assess real soiling and complexity. Drag & drop or click to add.":
    "اختياري، لكن الصور تتيح للذكاء الاصطناعي تقييم الاتساخ والتعقيد الفعلي. اسحب وأفلت أو انقر للإضافة.",
  "Drag & drop photos here": "اسحب وأفلت الصور هنا",
  "or click to browse · JPG, PNG, HEIC up to 20MB": "أو انقر للتصفح · JPG وPNG وHEIC حتى 20 ميجابايت",
  "Living Room": "غرفة المعيشة",
  "Kitchen": "المطبخ",
  "Bathroom": "الحمام",
  "Bedroom": "غرفة النوم",
  "Additional": "إضافي",
  "Sofas, floors, surfaces": "الأرائك والأرضيات والأسطح",
  "Counters, appliances, sink": "أسطح العمل والأجهزة والحوض",
  "Tiles, fixtures, grout": "البلاط والتجهيزات والفواصل",
  "Floors, wardrobes, dust": "الأرضيات والخزائن والغبار",
  "Balcony, hallway, other": "الشرفة والممر وغيرها",
  "Add photo": "أضف صورة",
  "photo": "صورة",
  "photos": "صور",
  "photo added": "صورة مضافة",
  "photos added": "صورة مضافة",
  "Analyze with AI": "حلّل بالذكاء الاصطناعي",
  "Skip & analyze": "تخطٍّ وحلّل",

  // AI analysis
  "Generating your AI quotation": "إنشاء عرض السعر بالذكاء الاصطناعي",
  "Analyzing your property — this takes a few seconds.": "جارٍ تحليل عقارك — يستغرق ذلك بضع ثوانٍ.",
  "Reviewing property information": "مراجعة معلومات العقار",
  "Type, size, rooms & cleaning scope": "النوع والحجم والغرف ونطاق التنظيف",
  "Assessing cleaning complexity": "تقييم تعقيد التنظيف",
  "Reading photo signals & soiling levels": "قراءة إشارات الصور ومستويات الاتساخ",
  "Estimating labor requirements": "تقدير متطلبات العمالة",
  "Hours, team size & scheduling": "الساعات وحجم الفريق والجدولة",
  "Calculating quotation": "حساب عرض السعر",
  "Rate model & property multipliers": "نموذج التسعير ومضاعفات العقار",
  "Generating recommendations": "إنشاء التوصيات",
  "Service match & confidence scoring": "مطابقة الخدمة وتقييم الثقة",
  "working…": "جارٍ العمل…",

  // Quote results
  "Quote generated": "تم إنشاء عرض السعر",
  "Your AI cleaning quotation": "عرض سعر التنظيف بالذكاء الاصطناعي",
  "Reference": "المرجع",
  "generated just now": "أُنشئ للتو",
  "Ask the AI assistant": "اسأل مساعد الذكاء الاصطناعي",
  "ESTIMATED PRICE RANGE": "نطاق السعر التقديري",
  "Estimated duration": "المدة التقديرية",
  "Recommended team": "الفريق الموصى به",
  "Complexity": "التعقيد",
  "hrs": "ساعة",
  "cleaner": "عامل",
  "cleaners": "عمّال",
  "AI reasoning": "تحليل الذكاء الاصطناعي",
  "How Rasaia built this estimate": "كيف بنت رسايا هذا التقدير",
  "Take action": "اتخذ إجراء",
  "Request a callback": "اطلب معاودة الاتصال",
  "Speak to an advisor": "تحدث إلى مستشار",
  "Download PDF quote": "تنزيل عرض السعر PDF",
  "Download Quote": "تنزيل عرض السعر",
  "Estimate valid for 14 days · no commitment": "التقدير صالح لمدة 14 يومًا · دون التزام",
  "Property summary": "ملخص العقار",
  "Size": "الحجم",
  "Questions about your quote?": "أسئلة حول عرض سعرك؟",
  "Chat with the AI assistant →": "تحدث مع مساعد الذكاء الاصطناعي ←",
  "Edit details": "تعديل التفاصيل",

  // Assistant
  "Quote Assistant": "مساعد عروض الأسعار",
  "AI · always available": "ذكاء اصطناعي · متاح دائمًا",
  "Ask about your quote…": "اسأل عن عرض سعرك…",
  "Why was this service recommended?": "لماذا تمت التوصية بهذه الخدمة؟",
  "Why do I need": "لماذا أحتاج",
  "cleaners?": "عمّال؟",
  "How was the estimate calculated?": "كيف تم حساب التقدير؟",
  "Can I reduce the estimate?": "هل يمكنني تقليل التقدير؟",

  // Booking
  "Book this cleaning": "احجز هذا التنظيف",
  "Lock in your estimate — our team confirms the details and schedules your visit.":
    "ثبّت تقديرك — يؤكد فريقنا التفاصيل ويجدول زيارتك.",
  "Full Name": "الاسم الكامل",
  "Phone Number": "رقم الهاتف",
  "Email": "البريد الإلكتروني",
  "Preferred Date": "التاريخ المفضل",
  "Notes": "ملاحظات",
  "e.g. Layla Haddad": "مثال: ليلى حداد",
  "e.g. +971 50 123 4567": "مثال: 4567 123 50 971+",
  "you@email.com": "you@email.com",
  "Access instructions, parking, special requests…": "تعليمات الدخول، وقوف السيارات، طلبات خاصة…",
  "Request Booking": "اطلب الحجز",
  "By requesting, you agree to be contacted about this quote. No payment is taken now.":
    "بإرسال الطلب، فإنك توافق على التواصل معك بشأن هذا العرض. لا يتم أخذ أي دفعة الآن.",
  "Booking requested": "تم طلب الحجز",
  "Thanks — we've received your booking request and will confirm shortly.":
    "شكرًا — استلمنا طلب الحجز وسنؤكده قريبًا.",
  "This field is required": "هذا الحقل مطلوب",
  "Enter a valid email": "أدخل بريدًا إلكترونيًا صحيحًا",

  // Contact
  "Need help? Talk to us": "تحتاج مساعدة؟ تواصل معنا",
  "Our advisors are available 7 days a week to help with quotes and bookings.":
    "مستشارونا متاحون 7 أيام في الأسبوع للمساعدة في العروض والحجوزات.",
  "Call us": "اتصل بنا",
  "Email us": "راسلنا",
  "Chat on WhatsApp": "الدردشة على واتساب",
  "Sun–Sat · 8am to 9pm": "الأحد–السبت · 8 صباحًا حتى 9 مساءً",
  "Replies within 1 business hour": "ردود خلال ساعة عمل واحدة",
  "Fastest response": "أسرع استجابة",

  // Confirmation
  "Request successfully submitted": "تم إرسال الطلب بنجاح",
  "An advisor will reach out shortly to walk you through your quote.":
    "سيتواصل معك مستشار قريبًا لشرح عرض سعرك.",
  "Our team has received your quote and will call you back to confirm details.":
    "استلم فريقنا عرض سعرك وسيعاود الاتصال بك لتأكيد التفاصيل.",
  "REFERENCE NUMBER": "رقم المرجع",
  "EXPECTED CALLBACK": "وقت المعاودة المتوقع",
  "Within 30 min": "خلال 30 دقيقة",
  "View the business portal": "عرض بوابة الأعمال",

  // Company portal
  "WORKSPACE": "مساحة العمل",
  "Dashboard": "لوحة التحكم",
  "Customer Requests": "طلبات العملاء",
  "Quote Management": "إدارة العروض",
  "AI Insights": "رؤى الذكاء الاصطناعي",
  "Operations lead": "مسؤول العمليات",
  "Customer site": "موقع العملاء",
  "Search requests…": "ابحث في الطلبات…",
  "Quotation activity across your business": "نشاط التسعير عبر أعمالك",
  "All requests": "كل الطلبات",
  "Total quotes generated": "إجمالي العروض المُنشأة",
  "Pending requests": "الطلبات المعلّقة",
  "Confirmed requests": "الطلبات المؤكدة",
  "Average quote value": "متوسط قيمة العرض",
  "Most requested": "الأكثر طلبًا",
  "new": "جديد",
  "Quotes generated": "العروض المُنشأة",
  "Last 12 months": "آخر 12 شهرًا",
  "Service mix": "توزيع الخدمات",
  "Recent requests": "الطلبات الأخيرة",
  "View all": "عرض الكل",
  "Customer": "العميل",
  "Est. price": "السعر التقديري",
  "Confidence": "الثقة",
  "Status": "الحالة",
  "total quotes": "إجمالي العروض",
  "awaiting action": "بانتظار الإجراء",
  "All": "الكل",
  "Pending": "معلّق",
  "Confirmed": "مؤكد",
  "In review": "قيد المراجعة",
  "Rejected": "مرفوض",
  "Search name or reference…": "ابحث بالاسم أو المرجع…",
  "No requests match your filters": "لا توجد طلبات تطابق عوامل التصفية",
  "Review, edit and decide on AI-generated quotes": "راجع وعدّل وقرّر بشأن العروض المُنشأة بالذكاء الاصطناعي",
  "Decision": "القرار",
  "Approve quote": "اعتماد العرض",
  "Edit quote": "تعديل العرض",
  "Reject quote": "رفض العرض",
  "Save changes": "حفظ التغييرات",
  "Quote approved & confirmed": "تم اعتماد العرض وتأكيده",
  "Quote rejected": "تم رفض العرض",
  "Quote updated": "تم تحديث العرض",
  "Approving notifies the customer and books the job. Rejecting sends a polite decline.":
    "الاعتماد يُخطر العميل ويحجز المهمة. الرفض يرسل اعتذارًا مهذبًا.",
  "Editing overrides the AI estimate. Changes are logged.": "التعديل يتجاوز تقدير الذكاء الاصطناعي. تُسجّل التغييرات.",
  "QUOTE PRICE": "سعر العرض",
  "DURATION": "المدة",
  "TEAM SIZE": "حجم الفريق",
  "Property details": "تفاصيل العقار",
  "Location": "الموقع",
  "Type": "النوع",
  "Submitted": "أُرسل",
  "What the quotation engine is learning about your business": "ما يتعلّمه محرك التسعير عن أعمالك",
  "Most requested service": "الخدمة الأكثر طلبًا",
  "Average property size": "متوسط مساحة العقار",
  "sq ft across all quotes": "قدم² عبر كل العروض",
  "Deep Cleaning demand": "الطلب على التنظيف العميق",
  "Service demand breakdown": "تفصيل الطلب على الخدمات",
  "Quote volume trend": "اتجاه حجم العروض",
  "Monthly": "شهري",
  "AI-generated business insights": "رؤى الأعمال المُنشأة بالذكاء الاصطناعي",
  "Updated automatically from quotation data": "تُحدّث تلقائيًا من بيانات التسعير",
  "AI insight": "رؤية ذكاء اصطناعي",
  "Deep Cleaning demand is climbing": "الطلب على التنظيف العميق في ارتفاع",
  "Deep Cleaning requests rose 18% over the last 30 days and now drive 41% of all quotes — the strongest contributor to average quote value.":
    "ارتفعت طلبات التنظيف العميق بنسبة 18% خلال آخر 30 يومًا وتشكّل الآن 41% من كل العروض — أكبر مساهم في متوسط قيمة العرض.",
  "High-confidence quotes convert better": "العروض عالية الثقة تتحوّل بشكل أفضل",
  "Quotes generated at 90%+ confidence convert to confirmed bookings 2.3× more often. Encouraging photo uploads is the biggest confidence lever.":
    "العروض المُنشأة بثقة 90%+ تتحول إلى حجوزات مؤكدة بمعدل 2.3 ضعفًا. تشجيع رفع الصور هو أكبر عامل لرفع الثقة.",
  "Villas are under-quoted on labor": "الفلل مسعّرة بأقل من اللازم على العمالة",
  "Villa jobs run 12% longer than estimated on average. Consider raising the villa labor multiplier from 1.15 to 1.22 to protect margin.":
    "مهام الفلل تستغرق 12% أطول من المقدّر في المتوسط. فكّر في رفع مضاعف عمالة الفيلا من 1.15 إلى 1.22 لحماية الهامش.",
  "Updated automatically": "يُحدّث تلقائيًا",

  // AI reasoning titles
  "Property profile": "ملف العقار",
  "Complexity class": "فئة التعقيد",
  "Labor & duration": "العمالة والمدة",
  "Photo signals": "إشارات الصور",
};

const DICTS = { en: {}, ar: AR };

const LangCtx = createContext({ lang: "en", setLang: () => {}, t: (s) => s, dir: "ltr", isRTL: false });

function LangProvider({ children }) {
  const [lang, setLangState] = useState(() => {
    try { return localStorage.getItem("rasaia_lang") || "en"; } catch (e) { return "en"; }
  });
  const isRTL = lang === "ar";
  const dir = isRTL ? "rtl" : "ltr";

  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = dir;
    try { localStorage.setItem("rasaia_lang", lang); } catch (e) {}
  }, [lang, dir]);

  const setLang = (l) => setLangState(l);
  const t = (s) => {
    if (lang === "en") return s;
    const d = DICTS[lang] || {};
    return Object.prototype.hasOwnProperty.call(d, s) ? d[s] : s;
  };

  return <LangCtx.Provider value={{ lang, setLang, t, dir, isRTL }}>{children}</LangCtx.Provider>;
}

function useLang() { return useContext(LangCtx); }

/* ---- Language toggle (segmented EN | ع) ---- */
function LanguageToggle({ compact }) {
  const { lang, setLang } = useLang();
  const opts = [{ k: "en", label: "EN" }, { k: "ar", label: "ع" }];
  return (
    <div className="row" style={{ background: "var(--surface-2)", border: "1px solid var(--line)", borderRadius: 999, padding: 3, gap: 2, height: compact ? 38 : 42 }}>
      {opts.map(o => {
        const active = lang === o.k;
        return (
          <button key={o.k} onClick={() => setLang(o.k)} aria-label={o.k === "en" ? "English" : "Arabic"} style={{
            height: "100%", padding: "0 13px", borderRadius: 999, fontSize: 13.5, fontWeight: 700,
            fontFamily: o.k === "ar" ? "var(--font)" : "inherit",
            background: active ? "var(--blue-600)" : "transparent", color: active ? "#fff" : "var(--ink-2)",
            transition: "background .15s, color .15s",
          }}>{o.label}</button>
        );
      })}
    </div>
  );
}

Object.assign(window, { LangProvider, useLang, LanguageToggle });
