/* ============================================================
   Rasaia Clean AI — Professional PDF quote export (jsPDF)
   Business documents render in English for font reliability.
   ============================================================ */

function generateQuotePDF(est, ref) {
  const jsPDFCtor = window.jspdf && window.jspdf.jsPDF;
  if (!jsPDFCtor) { alert("PDF library is still loading — please try again in a moment."); return; }

  const doc = new jsPDFCtor({ unit: "pt", format: "a4" });
  const W = doc.internal.pageSize.getWidth();   // 595
  const M = 48;                                  // margin
  const NAVY = [11, 23, 52], BLUE = [35, 71, 217], INK = [12, 21, 38], INK3 = [103, 116, 140], LINE = [228, 233, 242];
  const money = (n) => "AED " + Math.round(n).toLocaleString("en-US");
  const pt = (Rasaia.PROPERTY_TYPES.find(p => p.key === est.input.propertyType) || {}).label || "Property";

  /* ---- Header band ---- */
  doc.setFillColor(...NAVY); doc.rect(0, 0, W, 108, "F");
  doc.setFillColor(...BLUE); doc.roundedRect(M, 34, 34, 34, 8, 8, "F");
  doc.setTextColor(255, 255, 255);
  doc.setFont("helvetica", "bold"); doc.setFontSize(11);
  doc.text("R", M + 17, 56, { align: "center" });
  doc.setFontSize(17); doc.text("Rasaia Clean AI", M + 46, 50);
  doc.setFont("helvetica", "normal"); doc.setFontSize(9); doc.setTextColor(180, 195, 230);
  doc.text("AI CLEANING QUOTATION", M + 46, 66);
  doc.setFontSize(9); doc.setTextColor(210, 220, 245);
  doc.text("Reference", W - M, 46, { align: "right" });
  doc.setFont("helvetica", "bold"); doc.setFontSize(13); doc.setTextColor(255, 255, 255);
  doc.text(ref, W - M, 62, { align: "right" });

  let y = 150;
  const label = (txt, yy) => { doc.setFont("helvetica", "bold"); doc.setFontSize(8.5); doc.setTextColor(...INK3); doc.text(txt.toUpperCase(), M, yy); };
  const rule = (yy) => { doc.setDrawColor(...LINE); doc.setLineWidth(1); doc.line(M, yy, W - M, yy); };

  /* ---- Recommended service ---- */
  label("Recommended service", y);
  doc.setFont("helvetica", "bold"); doc.setFontSize(22); doc.setTextColor(...INK);
  doc.text(est.service.name, M, y + 26);
  doc.setFont("helvetica", "normal"); doc.setFontSize(10); doc.setTextColor(...INK3);
  doc.text(doc.splitTextToSize(est.service.blurb, W - 2 * M - 130), M, y + 46);

  // confidence chip (right)
  doc.setFillColor(238, 243, 255); doc.roundedRect(W - M - 120, y - 6, 120, 50, 10, 10, "F");
  doc.setFont("helvetica", "bold"); doc.setFontSize(22); doc.setTextColor(...BLUE);
  doc.text(est.confidence + "%", W - M - 60, y + 20, { align: "center" });
  doc.setFont("helvetica", "normal"); doc.setFontSize(8); doc.setTextColor(...INK3);
  doc.text("AI CONFIDENCE", W - M - 60, y + 34, { align: "center" });

  y += 78; rule(y); y += 28;

  /* ---- Metric row: duration / team / complexity ---- */
  const metrics = [
    ["Estimated duration", "~" + est.durationHours + " hrs"],
    ["Recommended team", est.team + (est.team > 1 ? " cleaners" : " cleaner")],
    ["Complexity", est.complexity],
  ];
  const colW = (W - 2 * M) / 3;
  metrics.forEach((m, i) => {
    const x = M + i * colW;
    doc.setFont("helvetica", "normal"); doc.setFontSize(8.5); doc.setTextColor(...INK3);
    doc.text(m[0].toUpperCase(), x, y);
    doc.setFont("helvetica", "bold"); doc.setFontSize(15); doc.setTextColor(...INK);
    doc.text(m[1], x, y + 20);
  });
  y += 44; rule(y); y += 26;

  /* ---- Price range band ---- */
  doc.setFillColor(11, 23, 52); doc.roundedRect(M, y, W - 2 * M, 64, 12, 12, "F");
  doc.setFont("helvetica", "normal"); doc.setFontSize(9); doc.setTextColor(180, 195, 230);
  doc.text("ESTIMATED PRICE RANGE", M + 20, y + 24);
  doc.setFont("helvetica", "bold"); doc.setFontSize(20); doc.setTextColor(255, 255, 255);
  doc.text(money(est.priceLow) + "  –  " + money(est.priceHigh), M + 20, y + 48);
  y += 92;

  /* ---- Property information ---- */
  label("Property information", y); y += 16;
  const info = [
    ["Property type", pt],
    ["Size", est.input.size.toLocaleString() + " sq ft"],
    ["Bedrooms", String(est.input.bedrooms)],
    ["Bathrooms", String(est.input.bathrooms)],
    ["Cleaning type", est.service.name],
  ];
  info.forEach((r, i) => {
    const yy = y + i * 22;
    doc.setFont("helvetica", "normal"); doc.setFontSize(10); doc.setTextColor(...INK3);
    doc.text(r[0], M, yy);
    doc.setFont("helvetica", "bold"); doc.setFontSize(10); doc.setTextColor(...INK);
    doc.text(r[1], W - M, yy, { align: "right" });
    doc.setDrawColor(...LINE); doc.setLineWidth(0.6); doc.line(M, yy + 7, W - M, yy + 7);
  });
  y += info.length * 22 + 18;

  /* ---- AI reasoning ---- */
  label("AI reasoning", y); y += 18;
  doc.setFontSize(9.5);
  est.reasoning.forEach((r, i) => {
    doc.setFont("helvetica", "bold"); doc.setTextColor(...BLUE);
    doc.text(String(i + 1).padStart(2, "0"), M, y);
    doc.setTextColor(...INK); doc.text(r.t, M + 24, y);
    doc.setFont("helvetica", "normal"); doc.setTextColor(...INK3);
    const lines = doc.splitTextToSize(r.d, W - 2 * M - 24);
    doc.text(lines, M + 24, y + 14);
    y += 14 + lines.length * 12 + 12;
  });

  /* ---- Footer ---- */
  const fy = doc.internal.pageSize.getHeight() - 40;
  doc.setDrawColor(...LINE); doc.line(M, fy - 14, W - M, fy - 14);
  doc.setFont("helvetica", "normal"); doc.setFontSize(8); doc.setTextColor(...INK3);
  doc.text("Estimate valid for 14 days from issue · No commitment required · Generated by Rasaia Clean AI", M, fy);
  doc.text(new Date().toLocaleDateString("en-GB"), W - M, fy, { align: "right" });

  doc.save("Rasaia-Quote-" + ref + ".pdf");
}

window.generateQuotePDF = generateQuotePDF;
