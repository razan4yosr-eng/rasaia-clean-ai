/* ============================================================
   Booking Request Form + Contact Section
   Appended to the quotation results page. Matches existing styling.
   ============================================================ */

const CONTACT = {
  phone: "+971 4 555 0199",
  phoneHref: "tel:+97145550199",
  email: "hello@rasaiaclean.ai",
  whatsapp: "+971 50 555 0199",
  whatsappHref: "https://wa.me/971505550199",
};

function FieldShell({ label, required, error, children }) {
  return (
    <div>
      <label className="field-label">{label}{required && <span style={{ color: "var(--red-600)", marginInlineStart: 3 }}>*</span>}</label>
      {children}
      {error && <div style={{ color: "var(--red-600)", fontSize: 12, marginTop: 6, fontWeight: 600 }}>{error}</div>}
    </div>
  );
}

function BookingForm({ est, refNo }) {
  const { t, isRTL } = useLang();
  const [form, setForm] = useState({ name: "", phone: "", email: "", date: "", notes: "" });
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);
  const set = (k, v) => { setForm(f => ({ ...f, [k]: v })); setErrors(e => ({ ...e, [k]: null })); };

  const submit = (e) => {
    e.preventDefault();
    const err = {};
    if (!form.name.trim()) err.name = t("This field is required");
    if (!form.phone.trim()) err.phone = t("This field is required");
    if (!form.email.trim()) err.email = t("This field is required");
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) err.email = t("Enter a valid email");
    if (Object.keys(err).length) { setErrors(err); return; }
    setSubmitted(true);
  };

  if (submitted) {
    return (
      <div className="card scale-in" style={{ padding: 36, textAlign: "center", borderColor: "var(--green-100)" }}>
        <div style={{ width: 60, height: 60, margin: "0 auto", borderRadius: "50%", background: "var(--green-600)", color: "#fff", display: "grid", placeItems: "center", boxShadow: "0 10px 24px rgba(14,159,110,.35)", animation: "popCheck .5s" }}><Icon name="check" size={30} stroke={3} /></div>
        <h3 className="t-h3" style={{ marginTop: 18 }}>{t("Booking requested")}</h3>
        <p className="muted" style={{ marginTop: 8, maxWidth: 380, marginInline: "auto", lineHeight: 1.55 }}>{t("Thanks — we've received your booking request and will confirm shortly.")}</p>
        <div className="row gap-3" style={{ justifyContent: "center", marginTop: 18, flexWrap: "wrap" }}>
          <Badge kind="gray">{t("Reference")} <span className="mono" style={{ fontWeight: 700 }}>{refNo}</span></Badge>
          <Badge kind="blue">{est.service.name}</Badge>
        </div>
      </div>
    );
  }

  return (
    <div className="card" style={{ padding: 0, overflow: "hidden" }}>
      <div style={{ padding: "22px 28px", borderBottom: "1px solid var(--line)" }}>
        <div className="row gap-3">
          <div style={{ width: 38, height: 38, borderRadius: 11, background: "var(--blue-50)", color: "var(--blue-600)", display: "grid", placeItems: "center" }}><Icon name="clock" size={20} /></div>
          <div><h3 className="t-h3">{t("Book this cleaning")}</h3><div className="muted" style={{ fontSize: 13, marginTop: 2 }}>{t("Lock in your estimate — our team confirms the details and schedules your visit.")}</div></div>
        </div>
      </div>
      <form onSubmit={submit} style={{ padding: 28 }}>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 18 }} className="bk-grid">
          <FieldShell label={t("Full Name")} required error={errors.name}>
            <input className="input" placeholder={t("e.g. Layla Haddad")} value={form.name} onChange={e => set("name", e.target.value)} />
          </FieldShell>
          <FieldShell label={t("Phone Number")} required error={errors.phone}>
            <input className="input" dir="ltr" style={{ textAlign: isRTL ? "right" : "left" }} placeholder={t("e.g. +971 50 123 4567")} value={form.phone} onChange={e => set("phone", e.target.value)} />
          </FieldShell>
          <FieldShell label={t("Email")} required error={errors.email}>
            <input className="input" type="email" dir="ltr" style={{ textAlign: isRTL ? "right" : "left" }} placeholder={t("you@email.com")} value={form.email} onChange={e => set("email", e.target.value)} />
          </FieldShell>
          <FieldShell label={t("Preferred Date")}>
            <input className="input" type="date" value={form.date} onChange={e => set("date", e.target.value)} />
          </FieldShell>
        </div>
        <div style={{ marginTop: 18 }}>
          <FieldShell label={t("Notes")}>
            <textarea className="input" style={{ height: 92, padding: "12px 16px", resize: "vertical" }} placeholder={t("Access instructions, parking, special requests…")} value={form.notes} onChange={e => set("notes", e.target.value)} />
          </FieldShell>
        </div>
        <div className="row gap-4" style={{ marginTop: 22, justifyContent: "space-between", flexWrap: "wrap" }}>
          <span className="muted" style={{ fontSize: 12, maxWidth: 360, lineHeight: 1.5 }}>{t("By requesting, you agree to be contacted about this quote. No payment is taken now.")}</span>
          <button type="submit" className="btn btn-primary btn-lg"><Icon name="check" size={18} stroke={2.5} /> {t("Request Booking")}</button>
        </div>
      </form>
      <style>{`@media(max-width:620px){.bk-grid{grid-template-columns:1fr!important}}`}</style>
    </div>
  );
}

function ContactSection() {
  const { t } = useLang();
  const cards = [
    { icon: "phone", title: t("Call us"), value: CONTACT.phone, sub: t("Sun–Sat · 8am to 9pm"), href: CONTACT.phoneHref, tone: "blue" },
    { icon: "doc", title: t("Email us"), value: CONTACT.email, sub: t("Replies within 1 business hour"), href: "mailto:" + CONTACT.email, tone: "blue" },
  ];
  return (
    <div className="card" style={{ padding: 28 }}>
      <div className="row gap-3" style={{ marginBottom: 20 }}>
        <div style={{ width: 38, height: 38, borderRadius: 11, background: "var(--ai-100)", color: "var(--ai-500)", display: "grid", placeItems: "center" }}><Icon name="headset" size={20} /></div>
        <div><h3 className="t-h3">{t("Need help? Talk to us")}</h3><div className="muted" style={{ fontSize: 13, marginTop: 2 }}>{t("Our advisors are available 7 days a week to help with quotes and bookings.")}</div></div>
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }} className="ct-grid">
        {cards.map(c => (
          <a key={c.title} href={c.href} className="row gap-3" style={{ padding: 16, borderRadius: 14, border: "1px solid var(--line)", background: "var(--surface-2)", transition: "border-color .15s" }}
            onMouseEnter={e => e.currentTarget.style.borderColor = "var(--blue-300)"} onMouseLeave={e => e.currentTarget.style.borderColor = "var(--line)"}>
            <div style={{ width: 40, height: 40, borderRadius: 11, background: "var(--surface)", color: "var(--blue-600)", display: "grid", placeItems: "center", flexShrink: 0, border: "1px solid var(--line)" }}><Icon name={c.icon} size={19} /></div>
            <div style={{ minWidth: 0 }}><div style={{ fontWeight: 700, fontSize: 14.5 }}>{c.title}</div><div className="mono" style={{ fontSize: 13, color: "var(--blue-700)", marginTop: 2, direction: "ltr", whiteSpace: "nowrap" }}>{c.value}</div><div className="muted" style={{ fontSize: 11.5, marginTop: 3 }}>{c.sub}</div></div>
          </a>
        ))}
      </div>
      <a href={CONTACT.whatsappHref} target="_blank" rel="noreferrer" className="row gap-3" style={{ marginTop: 14, padding: 16, borderRadius: 14, background: "#1FA855", color: "#fff", textDecoration: "none" }}>
        <div style={{ width: 40, height: 40, borderRadius: 11, background: "rgba(255,255,255,.18)", display: "grid", placeItems: "center", flexShrink: 0 }}><Icon name="chat" size={20} /></div>
        <div className="grow"><div style={{ fontWeight: 700, fontSize: 14.5 }}>{t("Chat on WhatsApp")}</div><div style={{ fontSize: 12.5, color: "rgba(255,255,255,.85)", marginTop: 2, direction: "ltr" }}>{CONTACT.whatsapp}</div></div>
        <Badge kind="gray" >{t("Fastest response")}</Badge>
      </a>
      <style>{`@media(max-width:620px){.ct-grid{grid-template-columns:1fr!important}}`}</style>
    </div>
  );
}

Object.assign(window, { BookingForm, ContactSection, CONTACT });
