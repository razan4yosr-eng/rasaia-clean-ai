/* ============================================================
   Screen 1 — Landing Page
   ============================================================ */

function NavBar({ onStart, onCompany, dark }) {
  const { t } = useLang();
  return (
    <header style={{ position: "sticky", top: 0, zIndex: 50, background: "rgba(255,255,255,.82)", backdropFilter: "blur(14px)", borderBottom: "1px solid var(--line)" }}>
      <div className="container row" style={{ height: 70, justifyContent: "space-between" }}>
        <Logo size={30} />
        <nav className="row gap-6" style={{ display: "flex" }}>
          <a className="nav-link" href="#how">{t("How it works")}</a>
          <a className="nav-link" href="#benefits">{t("Benefits")}</a>
          <a className="nav-link" href="#services">{t("Services")}</a>
        </nav>
        <div className="row gap-3">
          <LanguageToggle compact />
          <button className="btn btn-ghost btn-sm" onClick={onCompany}>
            <Icon name="dashboard" size={16} /> {t("Business portal")}
          </button>
          <button className="btn btn-primary btn-sm" onClick={onStart}>{t("Start estimate")}</button>
        </div>
      </div>
      <style>{`.nav-link{font-size:14.5px;font-weight:600;color:var(--ink-2);transition:color .15s}.nav-link:hover{color:var(--blue-600)}
      @media(max-width:980px){header nav{display:none!important}}`}</style>
    </header>
  );
}

function HeroQuoteCard() {
  const { t } = useLang();
  return (
    <div className="card" style={{ padding: 0, overflow: "hidden", boxShadow: "var(--sh-xl)", width: "100%", maxWidth: 420 }}>
      <div style={{ background: "linear-gradient(140deg, var(--blue-700), var(--navy))", padding: "20px 22px", color: "#fff" }}>
        <div className="row" style={{ justifyContent: "space-between", alignItems: "center" }}>
          <Badge kind="ai" dot>{t("AI estimate ready")}</Badge>
          <span className="mono" style={{ fontSize: 11, color: "rgba(255,255,255,.6)" }}>RQ-4821</span>
        </div>
        <div style={{ marginTop: 16, fontSize: 13, color: "rgba(255,255,255,.7)" }}>{t("Recommended service")}</div>
        <div className="row" style={{ justifyContent: "space-between", alignItems: "flex-end", marginTop: 4 }}>
          <div style={{ fontSize: 22, fontWeight: 800, letterSpacing: "-.02em" }}>{t("Deep Cleaning")}</div>
        </div>
      </div>
      <div style={{ padding: 22 }}>
        <div className="row" style={{ justifyContent: "space-between", marginBottom: 16 }}>
          <div>
            <div className="mono" style={{ fontSize: 10.5, color: "var(--ink-3)", letterSpacing: ".08em" }}>{t("ESTIMATED RANGE")}</div>
            <div style={{ fontSize: 28, fontWeight: 800, letterSpacing: "-.02em", marginTop: 3 }} className="keep-ltr">AED 1,060–1,340</div>
          </div>
          <ConfidenceRing value={92} size={74} />
        </div>
        <div className="row gap-3" style={{ display: "grid", gridTemplateColumns: "1fr 1fr" }}>
          {[["clock", t("Duration"), t("~4.5 hrs")], ["users", t("Team"), t("2 cleaners")]].map(([ic, l, v]) => (
            <div key={l} style={{ background: "var(--surface-2)", borderRadius: 12, padding: "12px 14px" }}>
              <div className="row gap-2" style={{ color: "var(--blue-600)" }}><Icon name={ic} size={15} /><span style={{ fontSize: 12, color: "var(--ink-3)", fontWeight: 600 }}>{l}</span></div>
              <div style={{ fontSize: 16, fontWeight: 700, marginTop: 5 }}>{v}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function Landing({ onStart, onCompany }) {
  const { t } = useLang();
  const benefits = [
    { icon: "bolt", title: "Instant, not hours later", body: "Replace back-and-forth WhatsApp threads with a quote generated the moment a customer submits." },
    { icon: "shield", title: "Consistent every time", body: "The same property always gets the same estimate — no more variance between employees." },
    { icon: "insights", title: "Smarter with every photo", body: "AI reads property photos to refine complexity, labor and pricing — and shows its reasoning." },
    { icon: "money", title: "Protect your margins", body: "Transparent labor and team-size logic keeps every quote priced to win without underselling." },
  ];
  const steps = [
    { n: "01", icon: "building", title: "Describe the property", body: "Type, size, bedrooms, bathrooms and the cleaning needed." },
    { n: "02", icon: "image", title: "Upload a few photos", body: "Living room, kitchen, bathrooms — anything that helps." },
    { n: "03", icon: "sparkle", title: "Get an instant quote", body: "Service, duration, team size and a clear price range." },
  ];
  const services = Object.values(Rasaia.SERVICES);

  return (
    <div style={{ background: "var(--surface)" }}>
      <NavBar onStart={onStart} onCompany={onCompany} />

      {/* HERO */}
      <section style={{ position: "relative", overflow: "hidden" }}>
        <div style={{ position: "absolute", inset: 0, background: "radial-gradient(1200px 500px at 78% -10%, var(--blue-50), transparent 60%)" }} />
        <div className="container" style={{ position: "relative", padding: "72px 24px 80px" }}>
          <div style={{ display: "grid", gridTemplateColumns: "1.05fr .95fr", gap: 56, alignItems: "center" }} className="hero-grid">
            <div className="fade-up">
              <Badge kind="blue" dot>{t("AI-powered cleaning quotations")}</Badge>
              <h1 className="t-display" style={{ marginTop: 20 }}>
                {t("Get an instant cleaning estimate in")} <span style={{ background: "linear-gradient(120deg, var(--blue-600), var(--ai-500))", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>{t("under 2 minutes")}</span>
              </h1>
              <p className="lead" style={{ marginTop: 22, maxWidth: 520 }}>
                {t("Rasaia Clean AI turns property details and a handful of photos into a precise, consistent quotation — service, labor, duration and price — without a single WhatsApp message.")}
              </p>
              <div className="row gap-3 wrap" style={{ marginTop: 32 }}>
                <button className="btn btn-primary btn-lg" onClick={onStart}>
                  {t("Start your estimate")} <Icon name="arrowRight" size={18} />
                </button>
                <button className="btn btn-ghost btn-lg" onClick={onCompany}>
                  <Icon name="dashboard" size={18} /> {t("View business portal")}
                </button>
              </div>
              <div className="row gap-6 wrap" style={{ marginTop: 36 }}>
                {[["1,284", t("quotes generated")], ["~90s", t("average time to quote")], ["94%", t("estimate accuracy")]].map(([v, l]) => (
                  <div key={l}>
                    <div style={{ fontSize: 24, fontWeight: 800, letterSpacing: "-.02em" }} className="keep-ltr">{v}</div>
                    <div className="muted" style={{ fontSize: 13 }}>{l}</div>
                  </div>
                ))}
              </div>
            </div>
            <div className="row" style={{ justifyContent: "center", position: "relative" }}>
              <div style={{ position: "absolute", width: 300, height: 300, borderRadius: "50%", background: "var(--blue-100)", filter: "blur(60px)", opacity: .7, zIndex: 0 }} />
              <div className="fade-up" style={{ animationDelay: ".12s", position: "relative", zIndex: 1 }}><HeroQuoteCard /></div>
            </div>
          </div>
        </div>
      </section>

      {/* TRUST STRIP */}
      <section style={{ borderTop: "1px solid var(--line)", borderBottom: "1px solid var(--line)", background: "var(--surface-2)" }}>
        <div className="container row wrap" style={{ padding: "20px 24px", gap: 14, justifyContent: "center", color: "var(--ink-3)" }}>
          <span style={{ fontSize: 13, fontWeight: 600 }}>{t("Built for cleaning companies that quote at scale")}</span>
          <span style={{ opacity: .4 }}>•</span>
          {["Residential", "Commercial", "Move-out & handover", "Post-renovation"].map(tg => (
            <span key={tg} className="badge badge-gray">{t(tg)}</span>
          ))}
        </div>
      </section>

      {/* HOW IT WORKS */}
      <section id="how" className="container" style={{ padding: "84px 24px" }}>
        <div style={{ textAlign: "center", maxWidth: 640, margin: "0 auto" }}>
          <div className="eyebrow">{t("How it works")}</div>
          <h2 className="t-h1" style={{ marginTop: 12 }}>{t("From property to priced quote in three steps")}</h2>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 24, marginTop: 48 }} className="g3">
          {steps.map((s, i) => (
            <div key={s.n} className="card" style={{ padding: 28, position: "relative" }}>
              <div className="row" style={{ justifyContent: "space-between", alignItems: "center" }}>
                <div style={{ width: 48, height: 48, borderRadius: 14, background: "linear-gradient(145deg, var(--blue-500), var(--blue-700))", color: "#fff", display: "grid", placeItems: "center", boxShadow: "var(--sh-blue)" }}>
                  <Icon name={s.icon} size={23} />
                </div>
                <span className="mono" style={{ fontSize: 30, fontWeight: 800, color: "var(--line)" }}>{s.n}</span>
              </div>
              <h3 className="t-h3" style={{ marginTop: 20 }}>{t(s.title)}</h3>
              <p className="muted" style={{ marginTop: 8, fontSize: 14.5, lineHeight: 1.55 }}>{t(s.body)}</p>
            </div>
          ))}
        </div>
      </section>

      {/* BENEFITS */}
      <section id="benefits" style={{ background: "var(--surface-2)", borderTop: "1px solid var(--line)" }}>
        <div className="container" style={{ padding: "84px 24px" }}>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1.2fr", gap: 56, alignItems: "center" }} className="hero-grid">
            <div>
              <div className="eyebrow">{t("Why Rasaia")}</div>
              <h2 className="t-h1" style={{ marginTop: 12 }}>{t("Stop guessing. Start quoting with confidence.")}</h2>
              <p className="lead" style={{ marginTop: 18 }}>
                {t("Manual quotes are slow and inconsistent — two employees, two prices. Rasaia standardizes the entire process behind one AI engine.")}
              </p>
              <button className="btn btn-dark btn-lg" style={{ marginTop: 28 }} onClick={onStart}>{t("Try it now")} <Icon name="arrowRight" size={18} /></button>
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 18 }} className="g2">
              {benefits.map(b => (
                <div key={b.title} className="card" style={{ padding: 24 }}>
                  <div style={{ width: 40, height: 40, borderRadius: 11, background: "var(--blue-50)", color: "var(--blue-600)", display: "grid", placeItems: "center" }}><Icon name={b.icon} size={20} /></div>
                  <h3 style={{ fontSize: 16.5, fontWeight: 700, marginTop: 16 }}>{t(b.title)}</h3>
                  <p className="muted" style={{ marginTop: 7, fontSize: 13.5, lineHeight: 1.55 }}>{t(b.body)}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* SERVICES */}
      <section id="services" className="container" style={{ padding: "84px 24px" }}>
        <div className="row" style={{ justifyContent: "space-between", alignItems: "flex-end", flexWrap: "wrap", gap: 16 }}>
          <div>
            <div className="eyebrow">{t("Services we price")}</div>
            <h2 className="t-h1" style={{ marginTop: 12 }}>{t("Every cleaning type, one engine")}</h2>
          </div>
          <button className="btn btn-soft" onClick={onStart}>{t("Get a quote")} <Icon name="arrowRight" size={16} /></button>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 18, marginTop: 40 }} className="g4">
          {services.map(s => (
            <div key={s.key} className="svc-card card" style={{ padding: 22, transition: "transform .18s, box-shadow .18s, border-color .18s", cursor: "pointer" }} onClick={onStart}>
              <Badge kind="blue">{t(s.complexity)}</Badge>
              <h3 className="t-h3" style={{ marginTop: 16 }}>{t(s.name)}</h3>
              <p className="muted" style={{ marginTop: 8, fontSize: 13.5, lineHeight: 1.5, minHeight: 60 }}>{t(s.blurb)}</p>
              <div className="row" style={{ color: "var(--blue-600)", fontSize: 14, fontWeight: 600, marginTop: 8 }}>{t("From")} {Rasaia.fmt(s.rate * 600)} <Icon name="arrowRight" size={15} style={{ marginInlineStart: 6 }} /></div>
            </div>
          ))}
        </div>
        <style>{`.svc-card:hover{transform:translateY(-4px);box-shadow:var(--sh-lg);border-color:var(--blue-200)}`}</style>
      </section>

      {/* CTA */}
      <section className="container" style={{ padding: "0 24px 90px" }}>
        <div style={{ borderRadius: 28, overflow: "hidden", position: "relative", background: "linear-gradient(135deg, var(--blue-700), var(--navy))", padding: "64px 48px", textAlign: "center", color: "#fff", boxShadow: "var(--sh-xl)" }}>
          <div style={{ position: "absolute", inset: 0, background: "radial-gradient(600px 300px at 20% 0%, rgba(110,89,242,.4), transparent 60%)" }} />
          <div style={{ position: "relative" }}>
            <h2 className="t-h1" style={{ color: "#fff" }}>{t("Your next quote is 2 minutes away")}</h2>
            <p className="lead" style={{ color: "rgba(255,255,255,.78)", marginTop: 16, maxWidth: 560, marginInline: "auto" }}>{t("No sign-up required to try. Generate a full AI quotation and see exactly how Rasaia thinks.")}</p>
            <button className="btn btn-lg" style={{ marginTop: 30, background: "#fff", color: "var(--blue-700)" }} onClick={onStart}>{t("Start your free estimate")} <Icon name="arrowRight" size={18} /></button>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer style={{ borderTop: "1px solid var(--line)", background: "var(--surface-2)" }}>
        <div className="container row" style={{ padding: "32px 24px", justifyContent: "space-between", flexWrap: "wrap", gap: 16 }}>
          <Logo size={26} />
          <span className="muted" style={{ fontSize: 13 }}>{t("© 2026 Rasaia Clean AI · Quotation intelligence for cleaning companies")}</span>
        </div>
      </footer>

      <style>{`
        @media(max-width:920px){ .hero-grid{grid-template-columns:1fr!important;gap:40px!important} .g4{grid-template-columns:1fr 1fr!important} .g3{grid-template-columns:1fr!important} }
        @media(max-width:560px){ .g2,.g4{grid-template-columns:1fr!important} .t-display{font-size:42px!important} }
      `}</style>
    </div>
  );
}

window.Landing = Landing;
window.NavBar = NavBar;
