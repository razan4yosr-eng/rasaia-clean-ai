/* ============================================================
   Screens 5–7 — Quote Results · AI Assistant · Confirmation
   ============================================================ */

function mdBold(text) {
  const parts = text.split(/(\*\*[^*]+\*\*)/g);
  return parts.map((p, i) => p.startsWith("**") ? <strong key={i} style={{ fontWeight: 700, color: "var(--ink)" }}>{p.slice(2, -2)}</strong> : <React.Fragment key={i}>{p}</React.Fragment>);
}

/* -------------------- AI Assistant drawer -------------------- */
function AssistantDrawer({ est, open, onClose }) {
  const { t, isRTL } = useLang();
  const hidden = isRTL ? "translateX(-102%)" : "translateX(102%)";
  const SUGGESTIONS = [t("Why was this service recommended?"), t("Why do I need") + " " + est.team + " " + t("cleaners?"), t("How was the estimate calculated?"), t("Can I reduce the estimate?")];
  const [msgs, setMsgs] = useState([{ role: "ai", text: `Hi! I'm your Rasaia quote assistant. I generated your **${est.service.name}** estimate of ${Rasaia.fmt(est.priceLow)}–${Rasaia.fmt(est.priceHigh)}. Ask me anything about how I arrived at it.` }]);
  const [typing, setTyping] = useState(false);
  const [text, setText] = useState("");
  const scrollRef = useRef(null);
  useEffect(() => { if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight; }, [msgs, typing]);

  const ask = (q) => {
    if (!q.trim()) return;
    setMsgs(m => [...m, { role: "user", text: q }]);
    setText(""); setTyping(true);
    setTimeout(() => {
      setTyping(false);
      setMsgs(m => [...m, { role: "ai", text: Rasaia.assistantAnswer(q, est) }]);
    }, 1100);
  };

  return (
    <>
      <div onClick={onClose} style={{ position: "fixed", inset: 0, background: "rgba(11,23,52,.4)", backdropFilter: "blur(2px)", zIndex: 90, opacity: open ? 1 : 0, pointerEvents: open ? "auto" : "none" }} />
      <aside style={{ position: "fixed", top: 0, insetInlineEnd: 0, bottom: 0, width: "min(440px, 94vw)", background: "var(--surface)", zIndex: 91, boxShadow: "var(--sh-xl)",
        transform: open ? "translateX(0)" : hidden, display: "flex", flexDirection: "column" }}>
        {/* header */}
        <div style={{ padding: "18px 20px", borderBottom: "1px solid var(--line)", background: "linear-gradient(135deg, var(--blue-700), var(--navy))", color: "#fff" }}>
          <div className="row" style={{ justifyContent: "space-between" }}>
            <div className="row gap-3">
              <div style={{ width: 38, height: 38, borderRadius: 11, background: "rgba(255,255,255,.15)", display: "grid", placeItems: "center" }}><Icon name="sparkle" size={20} stroke={0} style={{ fill: "#fff", stroke: "none" }} /></div>
              <div><div style={{ fontWeight: 700, fontSize: 15.5 }}>{t("Quote Assistant")}</div><div style={{ fontSize: 12, color: "rgba(255,255,255,.7)" }}>{t("AI · always available")}</div></div>
            </div>
            <button onClick={onClose} className="row" style={{ width: 34, height: 34, borderRadius: 10, color: "#fff", background: "rgba(255,255,255,.12)", justifyContent: "center" }}><Icon name="close" size={17} /></button>
          </div>
        </div>
        {/* messages */}
        <div ref={scrollRef} style={{ flex: 1, overflowY: "auto", padding: 20, display: "flex", flexDirection: "column", gap: 14, background: "var(--surface-2)" }}>
          {msgs.map((m, i) => (
            <div key={i} style={{ alignSelf: m.role === "user" ? "flex-end" : "flex-start", maxWidth: "86%" }} className="fade-up">
              <div style={{ padding: "12px 15px", borderRadius: m.role === "user" ? "16px 16px 4px 16px" : "16px 16px 16px 4px",
                background: m.role === "user" ? "var(--blue-600)" : "var(--surface)", color: m.role === "user" ? "#fff" : "var(--ink)",
                border: m.role === "user" ? "none" : "1px solid var(--line)", fontSize: 14, lineHeight: 1.55, boxShadow: "var(--sh-xs)" }}>
                {m.role === "ai" ? mdBold(m.text) : m.text}
              </div>
            </div>
          ))}
          {typing && (
            <div style={{ alignSelf: "flex-start" }}>
              <div className="row gap-2" style={{ padding: "14px 16px", borderRadius: "16px 16px 16px 4px", background: "var(--surface)", border: "1px solid var(--line)" }}>
                {[0, 1, 2].map(d => <span key={d} style={{ width: 7, height: 7, borderRadius: "50%", background: "var(--blue-400)", animation: `pulse 1s ${d * .15}s infinite` }} />)}
              </div>
            </div>
          )}
        </div>
        {/* suggestions + input */}
        <div style={{ padding: 16, borderTop: "1px solid var(--line)", background: "var(--surface)" }}>
          <div className="row wrap gap-2" style={{ marginBottom: 12 }}>
            {SUGGESTIONS.map(s => (
              <button key={s} onClick={() => ask(s)} style={{ fontSize: 12.5, fontWeight: 600, color: "var(--blue-700)", background: "var(--blue-50)", padding: "7px 12px", borderRadius: 99, transition: "background .15s" }}
                onMouseEnter={e => e.currentTarget.style.background = "var(--blue-100)"} onMouseLeave={e => e.currentTarget.style.background = "var(--blue-50)"}>{s}</button>
            ))}
          </div>
          <form className="row gap-2" onSubmit={e => { e.preventDefault(); ask(text); }}>
            <input className="input" style={{ height: 46 }} placeholder={t("Ask about your quote…")} value={text} onChange={e => setText(e.target.value)} />
            <button type="submit" className="btn btn-primary" style={{ width: 46, padding: 0, flexShrink: 0 }}><Icon name="send" size={18} /></button>
          </form>
        </div>
      </aside>
    </>
  );
}

/* -------------------- Screen 5: Quote Results -------------------- */
function QuoteResults({ est, onExit, onSubmit, onBack }) {
  const { t } = useLang();
  const REF = "RQ-4821";
  const [assistant, setAssistant] = useState(false);
  const [openReason, setOpenReason] = useState(0);
  const pt = Rasaia.PROPERTY_TYPES.find(p => p.key === est.input.propertyType);
  const summary = [
    { icon: pt?.icon || "home", label: t("Property type"), value: t(pt?.label) },
    { icon: "ruler", label: t("Size"), value: est.input.size.toLocaleString() + " " + t("sq ft") },
    { icon: "bed", label: t("Bedrooms"), value: est.input.bedrooms },
    { icon: "bath", label: t("Bathrooms"), value: est.input.bathrooms },
    { icon: "sparkle", label: t("Cleaning type"), value: t(est.service.name) },
  ];

  return (
    <WizardShell step={3} onExit={onExit}>
      <div className="container" style={{ maxWidth: 1080, padding: "40px 24px 110px" }}>
        <div className="row fade-up" style={{ justifyContent: "space-between", flexWrap: "wrap", gap: 12, marginBottom: 22 }}>
          <div>
            <Badge kind="green" dot>{t("Quote generated")}</Badge>
            <h1 className="t-h1" style={{ marginTop: 12 }}>{t("Your AI cleaning quotation")}</h1>
            <p className="muted" style={{ marginTop: 6 }}>{t("Reference")} <span className="mono">{REF}</span> · {t("generated just now")}</p>
          </div>
          <button className="btn btn-soft" onClick={() => setAssistant(true)}><Icon name="chat" size={17} /> {t("Ask the AI assistant")}</button>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "1.55fr 1fr", gap: 22, alignItems: "start" }} className="quote-grid">
          {/* LEFT */}
          <div className="col gap-5">
            {/* headline card */}
            <div className="card fade-up" style={{ padding: 0, overflow: "hidden" }}>
              <div style={{ background: "linear-gradient(135deg, var(--blue-700), var(--navy))", color: "#fff", padding: "26px 28px", position: "relative", overflow: "hidden" }}>
                <div style={{ position: "absolute", inset: 0, background: "radial-gradient(400px 200px at 90% 0%, rgba(110,89,242,.45), transparent 60%)" }} />
                <div className="row" style={{ position: "relative", justifyContent: "space-between", alignItems: "flex-start", flexWrap: "wrap", gap: 20 }}>
                  <div>
                    <div style={{ fontSize: 13, color: "rgba(255,255,255,.7)" }}>{t("Recommended service")}</div>
                    <div style={{ fontSize: 30, fontWeight: 800, letterSpacing: "-.02em", marginTop: 4 }}>{t(est.service.name)}</div>
                    <div style={{ fontSize: 14, color: "rgba(255,255,255,.78)", marginTop: 8, maxWidth: 340 }}>{t(est.service.blurb)}</div>
                    <div style={{ marginTop: 20 }}>
                      <div className="mono" style={{ fontSize: 11, color: "rgba(255,255,255,.6)", letterSpacing: ".08em" }}>{t("ESTIMATED PRICE RANGE")}</div>
                      <div style={{ fontSize: 34, fontWeight: 800, letterSpacing: "-.02em", marginTop: 4 }} className="keep-ltr">{Rasaia.fmt(est.priceLow)} – {Rasaia.fmt(est.priceHigh)}</div>
                    </div>
                  </div>
                  <div style={{ background: "rgba(255,255,255,.1)", borderRadius: 18, padding: 8 }}><ConfidenceRing value={est.confidence} size={120} /></div>
                </div>
              </div>
              {/* metric strip */}
              <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)" }}>
                {[["clock", t("Estimated duration"), `~${est.durationHours} ${t("hrs")}`], ["users", t("Recommended team"), `${est.team} ${est.team > 1 ? t("cleaners") : t("cleaner")}`], ["bolt", t("Complexity"), t(est.complexity)]].map(([ic, l, val], i) => (
                  <div key={l} style={{ padding: "20px 22px", borderInlineEnd: i < 2 ? "1px solid var(--line)" : "none" }}>
                    <div className="row gap-2" style={{ color: "var(--blue-600)" }}><Icon name={ic} size={17} /><span className="muted" style={{ fontSize: 12.5, fontWeight: 600 }}>{l}</span></div>
                    <div style={{ fontSize: 21, fontWeight: 800, marginTop: 8, letterSpacing: "-.01em" }}>{val}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* AI reasoning */}
            <div className="card fade-up" style={{ padding: 24, animationDelay: ".05s" }}>
              <div className="row gap-3" style={{ marginBottom: 18 }}>
                <div style={{ width: 36, height: 36, borderRadius: 10, background: "var(--ai-100)", color: "var(--ai-500)", display: "grid", placeItems: "center" }}><Icon name="sparkle" size={19} /></div>
                <div><h3 className="t-h3">{t("AI reasoning")}</h3><div className="muted" style={{ fontSize: 13 }}>{t("How Rasaia built this estimate")}</div></div>
              </div>
              <div className="col" style={{ gap: 8 }}>
                {est.reasoning.map((r, i) => {
                  const open = openReason === i;
                  return (
                    <div key={i} style={{ border: "1px solid var(--line)", borderRadius: 12, overflow: "hidden", background: open ? "var(--surface-2)" : "var(--surface)" }}>
                      <button onClick={() => setOpenReason(open ? -1 : i)} className="row" style={{ width: "100%", justifyContent: "space-between", padding: "14px 16px", textAlign: "start" }}>
                        <span className="row gap-3"><span className="mono" style={{ fontSize: 12, color: "var(--blue-600)", fontWeight: 600 }}>{String(i + 1).padStart(2, "0")}</span><span style={{ fontWeight: 700, fontSize: 14.5 }}>{t(r.t)}</span></span>
                        <Icon name="arrowRight" size={16} style={{ color: "var(--ink-3)", transform: open ? "rotate(90deg)" : "none", transition: "transform .2s" }} />
                      </button>
                      {open && <div className="muted fade-in" style={{ padding: "0 16px 16px 46px", fontSize: 13.5, lineHeight: 1.6 }}>{r.d}</div>}
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* RIGHT rail */}
          <div className="col gap-5" style={{ position: "sticky", top: 86 }}>
            <div className="card fade-up" style={{ padding: 22, animationDelay: ".08s" }}>
              <h3 style={{ fontSize: 15, fontWeight: 700, marginBottom: 16 }}>{t("Take action")}</h3>
              <div className="col gap-3">
                <button className="btn btn-primary btn-block" onClick={() => onSubmit("callback")}><Icon name="phone" size={17} /> {t("Request a callback")}</button>
                <button className="btn btn-ghost btn-block" onClick={() => onSubmit("advisor")}><Icon name="headset" size={17} /> {t("Speak to an advisor")}</button>
                <button className="btn btn-ghost btn-block" onClick={() => Rasaia_downloadPDF(est, REF)}><Icon name="doc" size={17} /> {t("Download PDF quote")}</button>
              </div>
              <div className="row gap-2" style={{ marginTop: 16, padding: "12px 14px", background: "var(--green-100)", borderRadius: 12, color: "var(--green-600)" }}>
                <Icon name="shield" size={17} /><span style={{ fontSize: 12.5, fontWeight: 600, lineHeight: 1.4 }}>{t("Estimate valid for 14 days · no commitment")}</span>
              </div>
            </div>

            <div className="card fade-up" style={{ padding: 22, animationDelay: ".12s" }}>
              <h3 style={{ fontSize: 15, fontWeight: 700, marginBottom: 14 }}>{t("Property summary")}</h3>
              <div className="col" style={{ gap: 0 }}>
                {summary.map((s, i) => (
                  <div key={s.label} className="row" style={{ justifyContent: "space-between", padding: "11px 0", borderTop: i ? "1px solid var(--line-2)" : "none" }}>
                    <span className="row gap-2 muted" style={{ fontSize: 13.5 }}><Icon name={s.icon} size={15} style={{ color: "var(--blue-500)" }} /> {s.label}</span>
                    <span style={{ fontSize: 13.5, fontWeight: 700 }}>{s.value}</span>
                  </div>
                ))}
              </div>
            </div>

            <button className="card fade-up" onClick={() => setAssistant(true)} style={{ padding: 18, animationDelay: ".15s", textAlign: "start", cursor: "pointer", border: "1px solid var(--blue-200)", background: "var(--blue-50)", display: "flex", gap: 14, alignItems: "center", width: "100%" }}>
              <div style={{ width: 40, height: 40, borderRadius: 11, background: "var(--blue-600)", color: "#fff", display: "grid", placeItems: "center", flexShrink: 0 }}><Icon name="chat" size={20} /></div>
              <div><div style={{ fontWeight: 700, fontSize: 14 }}>{t("Questions about your quote?")}</div><div className="muted" style={{ fontSize: 12.5 }}>{t("Chat with the AI assistant →")}</div></div>
            </button>
          </div>
        </div>

        {/* BOOKING + CONTACT */}
        <div className="col gap-5" style={{ marginTop: 22 }}>
          <BookingForm est={est} refNo={REF} />
          <ContactSection />
        </div>

        <div className="row" style={{ marginTop: 28 }}><button className="btn btn-ghost" onClick={onBack}><Icon name="arrowLeft" size={17} /> {t("Edit details")}</button></div>
      </div>

      <AssistantDrawer est={est} open={assistant} onClose={() => setAssistant(false)} />
      <style>{`@media(max-width:880px){.quote-grid{grid-template-columns:1fr!important}.quote-grid>div:last-child{position:static!important}}`}</style>
    </WizardShell>
  );
}

/* helper kept on window so the button can call into pdf.jsx */
function Rasaia_downloadPDF(est, ref) { if (window.generateQuotePDF) window.generateQuotePDF(est, ref); }

/* -------------------- Screen 7: Confirmation -------------------- */
function Confirmation({ est, mode, onHome, onCompany }) {
  const { t } = useLang();
  const ref = "RQ-4821";
  return (
    <div style={{ minHeight: "100vh", background: "var(--surface-2)", display: "flex", flexDirection: "column" }}>
      <header style={{ borderBottom: "1px solid var(--line)", background: "var(--surface)" }}>
        <div className="container row" style={{ height: 66, justifyContent: "space-between" }}><Logo size={28} /><div className="row gap-3"><LanguageToggle compact /><button className="btn btn-ghost btn-sm" onClick={onHome}>{t("Back to home")}</button></div></div>
      </header>
      <main className="row" style={{ flex: 1, justifyContent: "center", padding: "48px 24px" }}>
        <div className="card scale-in" style={{ maxWidth: 540, width: "100%", padding: 0, overflow: "hidden", boxShadow: "var(--sh-lg)" }}>
          <div style={{ padding: "44px 36px 32px", textAlign: "center", background: "linear-gradient(180deg, var(--green-100), var(--surface))" }}>
            <div style={{ width: 72, height: 72, margin: "0 auto", borderRadius: "50%", background: "var(--green-600)", display: "grid", placeItems: "center", color: "#fff", boxShadow: "0 12px 28px rgba(14,159,110,.4)", animation: "popCheck .5s" }}><Icon name="check" size={38} stroke={3} /></div>
            <h1 className="t-h2" style={{ marginTop: 22 }}>{t("Request successfully submitted")}</h1>
            <p className="muted" style={{ marginTop: 8, lineHeight: 1.55 }}>{mode === "advisor" ? t("An advisor will reach out shortly to walk you through your quote.") : t("Our team has received your quote and will call you back to confirm details.")}</p>
          </div>
          <div style={{ padding: "28px 36px 36px" }}>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
              <div style={{ background: "var(--surface-2)", borderRadius: 14, padding: "16px 18px" }}>
                <div className="mono muted" style={{ fontSize: 10.5, letterSpacing: ".08em" }}>{t("REFERENCE NUMBER")}</div>
                <div style={{ fontSize: 20, fontWeight: 800, marginTop: 5 }}>{ref}</div>
              </div>
              <div style={{ background: "var(--surface-2)", borderRadius: 14, padding: "16px 18px" }}>
                <div className="mono muted" style={{ fontSize: 10.5, letterSpacing: ".08em" }}>{t("EXPECTED CALLBACK")}</div>
                <div style={{ fontSize: 20, fontWeight: 800, marginTop: 5 }}>{t("Within 30 min")}</div>
              </div>
            </div>
            <div className="row gap-3" style={{ justifyContent: "space-between", padding: "16px 18px", marginTop: 12, background: "var(--blue-50)", borderRadius: 14 }}>
              <span className="row gap-2" style={{ fontSize: 13.5, fontWeight: 600, color: "var(--blue-700)" }}><Icon name="sparkle" size={16} /> {t(est.service.name)}</span>
              <span style={{ fontSize: 14, fontWeight: 800, color: "var(--blue-700)" }} className="keep-ltr">{Rasaia.fmt(est.priceLow)}–{Rasaia.fmt(est.priceHigh)}</span>
            </div>
            <div className="col gap-3" style={{ marginTop: 24 }}>
              <button className="btn btn-primary btn-block btn-lg" onClick={onHome}>{t("Done")}</button>
              <button className="btn btn-ghost btn-block" onClick={onCompany}><Icon name="dashboard" size={16} /> {t("View the business portal")}</button>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

Object.assign(window, { QuoteResults, Confirmation, AssistantDrawer, Rasaia_downloadPDF });
