/* ============================================================
   Screens 2–4 — Property Info · Photo Upload · AI Analysis
   ============================================================ */

const WIZ_STEPS = ["Property", "Photos", "Analysis", "Quote"];

function WizardShell({ step, onExit, children, footer }) {
  const { t } = useLang();
  return (
    <div style={{ minHeight: "100vh", background: "var(--surface-2)", display: "flex", flexDirection: "column" }}>
      <header style={{ position: "sticky", top: 0, zIndex: 40, background: "rgba(255,255,255,.85)", backdropFilter: "blur(12px)", borderBottom: "1px solid var(--line)" }}>
        <div className="container row" style={{ height: 66, justifyContent: "space-between", gap: 24 }}>
          <Logo size={28} />
          <div style={{ flex: 1, maxWidth: 560, display: "flex", justifyContent: "center" }} className="wiz-steps">
            <ProgressSteps steps={WIZ_STEPS.map(s => t(s))} current={step} />
          </div>
          <div className="row gap-3">
            <LanguageToggle compact />
            <button className="btn btn-ghost btn-sm" onClick={onExit}><Icon name="close" size={15} /> {t("Exit")}</button>
          </div>
        </div>
      </header>
      <main style={{ flex: 1 }}>{children}</main>
      {footer}
      <style>{`@media(max-width:820px){.wiz-steps{display:none!important}}`}</style>
    </div>
  );
}

function Stepper({ value, onChange, min = 0, max = 10, icon, label }) {
  return (
    <div>
      <span className="field-label">{label}</span>
      <div className="row" style={{ border: "1px solid var(--line)", borderRadius: 12, overflow: "hidden", background: "var(--surface)", height: 50 }}>
        <button onClick={() => onChange(Math.max(min, value - 1))} className="step-btn" style={{ width: 48, height: "100%", color: "var(--ink-2)", fontSize: 20 }}>−</button>
        <div className="row grow" style={{ justifyContent: "center", gap: 8, borderLeft: "1px solid var(--line)", borderRight: "1px solid var(--line)", height: "100%", color: "var(--blue-600)" }}>
          <Icon name={icon} size={17} /><span style={{ fontSize: 17, fontWeight: 700, color: "var(--ink)" }}>{value}</span>
        </div>
        <button onClick={() => onChange(Math.min(max, value + 1))} className="step-btn" style={{ width: 48, height: "100%", color: "var(--ink-2)", fontSize: 18 }}>+</button>
      </div>
      <style>{`.step-btn:hover{background:var(--surface-2);color:var(--blue-600)}`}</style>
    </div>
  );
}

function OptionCard({ active, icon, title, desc, onClick }) {
  return (
    <button onClick={onClick} style={{
      textAlign: "start", padding: 18, borderRadius: 16, width: "100%",
      border: active ? "1.5px solid var(--blue-600)" : "1.5px solid var(--line)",
      background: active ? "var(--blue-50)" : "var(--surface)",
      boxShadow: active ? "0 0 0 4px var(--blue-50)" : "var(--sh-xs)",
      transition: "all .15s", cursor: "pointer",
      display: "flex", gap: 14, alignItems: desc ? "flex-start" : "center",
    }}>
      <div style={{ width: 42, height: 42, borderRadius: 11, flexShrink: 0, display: "grid", placeItems: "center",
        background: active ? "var(--blue-600)" : "var(--surface-2)", color: active ? "#fff" : "var(--ink-2)", transition: "all .15s" }}>
        <Icon name={icon} size={21} />
      </div>
      <div style={{ flex: 1 }}>
        <div className="row" style={{ justifyContent: "space-between", alignItems: "center" }}>
          <span style={{ fontWeight: 700, fontSize: 15 }}>{title}</span>
          {active && <Icon name="check" size={16} stroke={3} style={{ color: "var(--blue-600)" }} />}
        </div>
        {desc && <div className="muted" style={{ fontSize: 13, marginTop: 4, lineHeight: 1.45 }}>{desc}</div>}
      </div>
    </button>
  );
}

/* -------------------- Screen 2: Property Info -------------------- */
function PropertyInfo({ value, onChange, onNext, onExit }) {
  const { t } = useLang();
  const v = value;
  const set = (patch) => onChange({ ...v, ...patch });
  return (
    <WizardShell step={0} onExit={onExit}>
      <div className="container" style={{ maxWidth: 760, padding: "44px 24px 120px" }}>
        <div className="fade-up">
          <div className="eyebrow">{t("Step 1 of 4")}</div>
          <h1 className="t-h1" style={{ marginTop: 10 }}>{t("Tell us about the property")}</h1>
          <p className="lead" style={{ marginTop: 10 }}>{t("The more accurate the details, the tighter your AI estimate.")}</p>
        </div>

        <div className="card fade-up" style={{ padding: 28, marginTop: 28, animationDelay: ".05s" }}>
          <span className="field-label">{t("Property type")}</span>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 12 }} className="g4">
            {Rasaia.PROPERTY_TYPES.map(p => (
              <OptionCard key={p.key} active={v.propertyType === p.key} icon={p.icon} title={t(p.label)} onClick={() => set({ propertyType: p.key })} />
            ))}
          </div>

          <div style={{ height: 1, background: "var(--line-2)", margin: "26px 0" }} />

          <div className="row" style={{ justifyContent: "space-between", alignItems: "baseline" }}>
            <span className="field-label" style={{ marginBottom: 0 }}>{t("Property size")}</span>
            <span style={{ fontWeight: 700, fontSize: 15 }}><span className="keep-ltr">{v.size.toLocaleString()}</span> <span className="muted" style={{ fontWeight: 500, fontSize: 13 }}>{t("sq ft")}</span></span>
          </div>
          <input type="range" min={350} max={6000} step={50} value={v.size} onChange={e => set({ size: +e.target.value })}
            style={{ width: "100%", marginTop: 14, accentColor: "var(--blue-600)" }} />
          <div className="row" style={{ justifyContent: "space-between", marginTop: 4 }}>
            <span className="mono muted" style={{ fontSize: 11 }}>350</span><span className="mono muted" style={{ fontSize: 11 }}>6,000 {t("sq ft")}</span>
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, marginTop: 26 }} className="g2">
            <Stepper label={t("Bedrooms")} icon="bed" value={v.bedrooms} onChange={n => set({ bedrooms: n })} min={0} max={8} />
            <Stepper label={t("Bathrooms")} icon="bath" value={v.bathrooms} onChange={n => set({ bathrooms: n })} min={1} max={8} />
          </div>
        </div>

        <div className="card fade-up" style={{ padding: 28, marginTop: 20, animationDelay: ".1s" }}>
          <span className="field-label">{t("Cleaning type")}</span>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }} className="g2">
            {Rasaia.CLEANING_TYPES.map(c => (
              <OptionCard key={c.key} active={v.cleaningType === c.key} icon="sparkle" title={t(c.label)} desc={t(c.desc)} onClick={() => set({ cleaningType: c.key })} />
            ))}
          </div>
        </div>
      </div>

      <div style={{ position: "sticky", bottom: 0, background: "rgba(255,255,255,.9)", backdropFilter: "blur(12px)", borderTop: "1px solid var(--line)" }}>
        <div className="container row" style={{ maxWidth: 760, justifyContent: "space-between", padding: "16px 24px" }}>
          <button className="btn btn-ghost" onClick={onExit}><Icon name="arrowLeft" size={17} /> {t("Back")}</button>
          <button className="btn btn-primary" onClick={onNext}>{t("Continue to photos")} <Icon name="arrowRight" size={17} /></button>
        </div>
      </div>
    </WizardShell>
  );
}

/* -------------------- Screen 3: Photo Upload -------------------- */
function PhotoUpload({ photos, onChange, onNext, onBack, onExit }) {
  const { t } = useLang();
  const [dragOver, setDragOver] = useState(false);
  const total = Object.values(photos).reduce((a, b) => a + b, 0);
  const addTo = (room, n = 1) => onChange({ ...photos, [room]: Math.min(6, (photos[room] || 0) + n) });
  const dropAll = () => onChange(Object.fromEntries(Rasaia.PHOTO_ROOMS.map(r => [r.key, Math.min(6, (photos[r.key] || 0) + 1)])));

  return (
    <WizardShell step={1} onExit={onExit}>
      <div className="container" style={{ maxWidth: 820, padding: "44px 24px 120px" }}>
        <div className="fade-up">
          <div className="eyebrow">{t("Step 2 of 4")}</div>
          <h1 className="t-h1" style={{ marginTop: 10 }}>{t("Add photos for a sharper estimate")}</h1>
          <p className="lead" style={{ marginTop: 10 }}>{t("Optional, but photos let the AI assess real soiling and complexity. Drag & drop or click to add.")}</p>
        </div>

        {/* Dropzone */}
        <div className="fade-up" onClick={dropAll}
          onDragOver={e => { e.preventDefault(); setDragOver(true); }}
          onDragLeave={() => setDragOver(false)}
          onDrop={e => { e.preventDefault(); setDragOver(false); dropAll(); }}
          style={{ marginTop: 24, borderRadius: 18, padding: "38px 24px", textAlign: "center", cursor: "pointer",
            border: `2px dashed ${dragOver ? "var(--blue-500)" : "#C5D0E4"}`, background: dragOver ? "var(--blue-50)" : "var(--surface)", transition: "all .15s" }}>
          <div style={{ width: 56, height: 56, borderRadius: 16, margin: "0 auto", background: "var(--blue-50)", color: "var(--blue-600)", display: "grid", placeItems: "center" }}><Icon name="upload" size={26} /></div>
          <div style={{ fontWeight: 700, fontSize: 16, marginTop: 16 }}>{t("Drag & drop photos here")}</div>
          <div className="muted" style={{ fontSize: 13.5, marginTop: 5 }}>{t("or click to browse · JPG, PNG, HEIC up to 20MB")}</div>
        </div>

        {/* Per-room */}
        <div className="col gap-5" style={{ marginTop: 28 }}>
          {Rasaia.PHOTO_ROOMS.map((room, ri) => (
            <div key={room.key} className="card fade-up" style={{ padding: 20, animationDelay: `${ri * .04}s` }}>
              <div className="row" style={{ justifyContent: "space-between", marginBottom: 14 }}>
                <div>
                  <div className="row gap-2"><span style={{ fontWeight: 700, fontSize: 15 }}>{t(room.label)}</span>{photos[room.key] > 0 && <Badge kind="green">{photos[room.key]}</Badge>}</div>
                  <div className="muted" style={{ fontSize: 12.5, marginTop: 2 }}>{t(room.hint)}</div>
                </div>
              </div>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(96px, 1fr))", gap: 10 }}>
                {Array.from({ length: photos[room.key] || 0 }).map((_, i) => <PhotoTile key={i} filled label={t(room.label)} />)}
                {(photos[room.key] || 0) < 6 && <PhotoTile onClick={() => addTo(room.key)} />}
              </div>
            </div>
          ))}
        </div>
      </div>

      <div style={{ position: "sticky", bottom: 0, background: "rgba(255,255,255,.9)", backdropFilter: "blur(12px)", borderTop: "1px solid var(--line)" }}>
        <div className="container row" style={{ maxWidth: 820, justifyContent: "space-between", padding: "16px 24px" }}>
          <button className="btn btn-ghost" onClick={onBack}><Icon name="arrowLeft" size={17} /> {t("Back")}</button>
          <div className="row gap-3">
            <span className="muted" style={{ fontSize: 13.5, fontWeight: 600 }}>{total} {total !== 1 ? t("photos") : t("photo")}</span>
            <button className="btn btn-primary" onClick={() => onNext(total)}>{total > 0 ? t("Analyze with AI") : t("Skip & analyze")} <Icon name="sparkle" size={17} /></button>
          </div>
        </div>
      </div>
    </WizardShell>
  );
}

/* -------------------- Screen 4: AI Analysis -------------------- */
function AIAnalysis({ onDone, onExit }) {
  const { t } = useLang();
  const STAGES = [
    { icon: "doc", label: "Reviewing property information", detail: "Type, size, rooms & cleaning scope" },
    { icon: "image", label: "Assessing cleaning complexity", detail: "Reading photo signals & soiling levels" },
    { icon: "users", label: "Estimating labor requirements", detail: "Hours, team size & scheduling" },
    { icon: "money", label: "Calculating quotation", detail: "Rate model & property multipliers" },
    { icon: "sparkle", label: "Generating recommendations", detail: "Service match & confidence scoring" },
  ];
  const [done, setDone] = useState(-1);
  const [active, setActive] = useState(0);
  useEffect(() => {
    let i = 0;
    setActive(0);
    const tick = () => {
      setDone(i);
      i++;
      if (i < STAGES.length) { setActive(i); setTimeout(tick, 820); }
      else setTimeout(() => onDone(), 700);
    };
    const tm = setTimeout(tick, 700);
    return () => clearTimeout(tm);
  }, []);
  const pct = Math.round(((done + 1) / STAGES.length) * 100);

  return (
    <WizardShell step={2} onExit={onExit}>
      <div className="container" style={{ maxWidth: 620, padding: "60px 24px 100px", textAlign: "center" }}>
        <div className="scale-in" style={{ width: 92, height: 92, margin: "0 auto", borderRadius: 26, position: "relative",
          background: "linear-gradient(145deg, var(--blue-500), var(--ai-500))", display: "grid", placeItems: "center", color: "#fff",
          boxShadow: "0 18px 40px rgba(35,71,217,.4)", animation: "ringPulse 2s infinite" }}>
          <Icon name="sparkle" size={44} stroke={0} style={{ fill: "#fff", stroke: "none" }} />
          <div style={{ position: "absolute", inset: -6, borderRadius: 30, border: "2px solid var(--blue-200)", borderTopColor: "transparent", animation: "spin 1.1s linear infinite" }} />
        </div>
        <h1 className="t-h2" style={{ marginTop: 28 }}>{t("Generating your AI quotation")}</h1>
        <p className="muted" style={{ marginTop: 8 }}>{t("Analyzing your property — this takes a few seconds.")}</p>

        {/* progress bar */}
        <div style={{ height: 7, background: "var(--surface-3)", borderRadius: 99, marginTop: 28, overflow: "hidden" }}>
          <div style={{ height: "100%", width: pct + "%", background: "linear-gradient(90deg, var(--blue-500), var(--ai-500))", borderRadius: 99, transition: "width .6s cubic-bezier(.3,.8,.3,1)" }} />
        </div>
        <div className="mono muted" style={{ fontSize: 11.5, marginTop: 8, textAlign: "end" }}>{pct}%</div>

        <div className="card" style={{ padding: 10, marginTop: 22, textAlign: "start" }}>
          {STAGES.map((s, i) => {
            const isDone = i <= done, isActive = i === active && !isDone;
            return (
              <div key={i} className="row gap-3" style={{ padding: "13px 14px", borderRadius: 12, background: isActive ? "var(--blue-50)" : "transparent", transition: "background .3s", opacity: i <= active || isDone ? 1 : .42 }}>
                <div style={{ width: 34, height: 34, borderRadius: 10, flexShrink: 0, display: "grid", placeItems: "center", transition: "all .3s",
                  background: isDone ? "var(--green-100)" : isActive ? "var(--blue-600)" : "var(--surface-3)",
                  color: isDone ? "var(--green-600)" : isActive ? "#fff" : "var(--ink-3)" }}>
                  {isDone ? <Icon name="check" size={17} stroke={3} style={{ animation: "popCheck .3s" }} />
                    : isActive ? <div style={{ width: 15, height: 15, borderRadius: "50%", border: "2.5px solid rgba(255,255,255,.45)", borderTopColor: "#fff", animation: "spin .8s linear infinite" }} />
                    : <Icon name={s.icon} size={17} />}
                </div>
                <div className="grow">
                  <div style={{ fontWeight: 600, fontSize: 14.5, color: isActive || isDone ? "var(--ink)" : "var(--ink-2)" }}>{t(s.label)}</div>
                  <div className="muted" style={{ fontSize: 12.5, marginTop: 1 }}>{t(s.detail)}</div>
                </div>
                {isActive && <span className="mono" style={{ fontSize: 11, color: "var(--blue-600)", animation: "pulse 1.2s infinite" }}>{t("working…")}</span>}
              </div>
            );
          })}
        </div>
      </div>
    </WizardShell>
  );
}

Object.assign(window, { WizardShell, PropertyInfo, PhotoUpload, AIAnalysis, WIZ_STEPS });
